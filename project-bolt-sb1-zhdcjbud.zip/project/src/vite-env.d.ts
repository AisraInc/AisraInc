/// <reference types="vite/client" />

interface Window {
  YT: any;
  onYouTubeIframeAPIReady: () => void;
}