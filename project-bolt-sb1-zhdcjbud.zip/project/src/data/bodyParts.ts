import { BodyPart } from '../types';

export const bodyParts: BodyPart[] = [
  // Neck Touch Point
  {
    id: 'neck-front',
    label: 'Neck',
    width: 53,
    height: 33,
    x: 199,
    y: 60,
    rotation: 0,
    side: 'front'
  },
  // Chest Touch Point
  {
    id: 'chest-front',
    label: 'Chest',
    width: 53,
    height: 42,
    x: 199,
    y: 93,
    rotation: 0,
    side: 'front'
  },
  // Left Shoulder Touch Point
  {
    id: 'shoulder-left-front',
    label: 'L. Shoulder',
    width: 45.23,
    height: 39.08,
    x: 258,
    y: 75,
    rotation: -27.05,
    side: 'L'
  },
  // Right Shoulder Touch Point
  {
    id: 'shoulder-right-front',
    label: 'R. Shoulder',
    width: 45.23,
    height: 39.08,
    x: 148,
    y: 75,
    rotation: -152.95,
    side: 'R'
  }
];