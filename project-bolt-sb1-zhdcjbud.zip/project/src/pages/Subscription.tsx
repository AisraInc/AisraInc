import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Home, Castle, Diamond, Check, AlertCircle } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';

// Initialize Stripe with a demo key for development
const DEMO_STRIPE_KEY = 'pk_test_demo_key';
const stripePromise = loadStripe(DEMO_STRIPE_KEY);

const Subscription: React.FC = () => {
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState<'basic' | 'monthly' | 'yearly'>('yearly');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const plans = {
    basic: {
      icon: Home,
      name: 'Basic',
      price: 'Free',
      period: 'Per month',
      features: [
        'Semi-custom Workouts',
        'Daily workouts',
        'Guided Videos',
      ],
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10',
      borderColor: 'border-blue-400/20',
    },
    monthly: {
      icon: Castle,
      name: 'Monthly',
      price: '$20',
      period: 'Per month',
      features: [
        'Custom Workouts',
        'Daily Alerts',
        'Body Analysis',
      ],
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
      borderColor: 'border-purple-400/20',
    },
    yearly: {
      icon: Diamond,
      name: 'Yearly',
      price: '$120',
      period: 'Per year',
      features: [
        'Save With Yearly',
        'Progress Tracking',
        'Community Interaction',
      ],
      color: 'text-[#42ACF9]',
      bgColor: 'bg-[#42ACF9]/10',
      borderColor: 'border-[#42ACF9]/20',
      bestChoice: true,
    },
  };

  const handleSubscribe = async (planType: 'basic' | 'monthly' | 'yearly') => {
    if (planType === 'basic') {
      alert('Free plan selected! Your account has been updated.');
      navigate('/profile');
      return;
    }

    if (planType === 'monthly') {
      window.location.href = 'https://buy.stripe.com/test_8wMg2RcQoh2C0yA7ss';
      return;
    }
    
    if (planType === 'yearly') {
      window.location.href = 'https://buy.stripe.com/test_4gw5odeYw4fQ3KMbIJ';
      return;
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-xl font-bold">Subscription Plans</h1>
            <p className="text-sm text-gray-400">Choose the plan that fits your needs</p>
          </div>
        </header>

        <main className="p-4 space-y-4">
          {/* Plans */}
          {(Object.keys(plans) as Array<keyof typeof plans>).map((planType) => {
            const plan = plans[planType];
            const isSelected = selectedPlan === planType;
            
            return (
              <div 
                key={planType}
                className={`relative p-6 rounded-xl border transition-all ${
                  isSelected 
                    ? `${plan.borderColor} ${plan.bgColor}` 
                    : 'border-gray-800 hover:border-gray-700'
                }`}
              >
                {plan.bestChoice && (
                  <div className="absolute -top-3 right-4 px-4 py-1 bg-[#42ACF9] rounded-full text-xs font-medium">
                    BEST CHOICE
                  </div>
                )}
                
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <plan.icon className={`w-5 h-5 ${plan.color}`} />
                      <h3 className="font-medium">{plan.name}</h3>
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-2xl font-bold">{plan.price}</span>
                      <span className="text-sm text-gray-400">{plan.period}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedPlan(planType)}
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center
                      ${isSelected 
                        ? `${plan.borderColor} ${plan.bgColor}` 
                        : 'border-gray-700'
                      }`}
                  >
                    {isSelected && <Check className="w-4 h-4" />}
                  </button>
                </div>

                <div className="space-y-2">
                  {plan.features.map((feature) => (
                    <div key={feature} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-300">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {/* Subscribe Button */}
          <button
            onClick={() => handleSubscribe(selectedPlan)}
            disabled={loading}
            className="w-full py-3 bg-[#42ACF9] text-white font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Processing...' : 'Subscribe Now'}
          </button>

          {/* Error Message */}
          {error && (
            <div className="flex items-start gap-2 p-4 bg-red-900/20 border border-red-900/50 rounded-lg">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          {/* Info Note */}
          <div className="flex items-start gap-2 p-4 bg-gray-900 rounded-lg">
            <AlertCircle className="w-5 h-5 text-gray-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-gray-400">
              You can cancel or change your subscription at any time. The subscription will automatically renew unless cancelled.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Subscription;