import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Shield, 
  Lock, 
  Trash2, 
  HardDrive, 
  Wifi, 
  Database,
  AlertCircle,
  RefreshCw,
  Download,
  Fingerprint
} from 'lucide-react';

const AppSettings: React.FC = () => {
  const navigate = useNavigate();
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);
  const [cacheSize, setCacheSize] = useState('234.5 MB');
  const [isClearing, setIsClearing] = useState(false);

  const handleClearCache = () => {
    setIsClearing(true);
    setTimeout(() => {
      setIsClearing(false);
      setCacheSize('0 MB');
    }, 1500);
  };

  const handleDeleteAccount = () => {
    setShowConfirmDelete(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">App Settings</h1>
        </header>

        <main className="p-4 space-y-6">
          {/* Security Section */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-[#42ACF9]" />
              Security
            </h2>
            <div className="space-y-4">
              <button className="w-full flex items-center justify-between p-4 bg-gray-900 rounded-xl hover:bg-gray-800 transition-colors">
                <div className="flex items-center gap-3">
                  <Lock className="w-5 h-5 text-gray-400" />
                  <span>Change Password</span>
                </div>
                <ArrowLeft className="w-5 h-5 text-gray-400 rotate-180" />
              </button>
              <button className="w-full flex items-center justify-between p-4 bg-gray-900 rounded-xl hover:bg-gray-800 transition-colors">
                <div className="flex items-center gap-3">
                  <Fingerprint className="w-5 h-5 text-gray-400" />
                  <span>Biometric Authentication</span>
                </div>
                <ArrowLeft className="w-5 h-5 text-gray-400 rotate-180" />
              </button>
            </div>
          </section>

          {/* Storage Section */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <HardDrive className="w-5 h-5 text-[#42ACF9]" />
              Storage
            </h2>
            <div className="space-y-4">
              <div className="p-4 bg-gray-900 rounded-xl">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-400">Cache Size</span>
                  <span>{cacheSize}</span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2 mb-4">
                  <div 
                    className="bg-[#42ACF9] h-2 rounded-full transition-all duration-300"
                    style={{ width: cacheSize === '0 MB' ? '0%' : '45%' }}
                  />
                </div>
                <button
                  onClick={handleClearCache}
                  disabled={isClearing || cacheSize === '0 MB'}
                  className="w-full py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isClearing ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Clearing...
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      Clear Cache
                    </>
                  )}
                </button>
              </div>
            </div>
          </section>

          {/* Network Section */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Wifi className="w-5 h-5 text-[#42ACF9]" />
              Network
            </h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-gray-900 rounded-xl">
                <div className="flex items-center gap-3">
                  <Database className="w-5 h-5 text-gray-400" />
                  <span>Download Over Cellular</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" className="sr-only peer" />
                  <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#42ACF9]"></div>
                </label>
              </div>
            </div>
          </section>

          {/* Danger Zone */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-red-500">
              <AlertCircle className="w-5 h-5" />
              Danger Zone
            </h2>
            <button
              onClick={handleDeleteAccount}
              className="w-full p-4 border border-red-500/20 bg-red-500/10 rounded-xl text-red-500 hover:bg-red-500/20 transition-colors flex items-center justify-center gap-2"
            >
              <Trash2 className="w-5 h-5" />
              Delete Account
            </button>
          </section>
        </main>

        {/* Delete Account Confirmation Modal */}
        {showConfirmDelete && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-fade-in">
            <div className="bg-gray-900 rounded-xl p-6 m-4 w-full max-w-sm">
              <h3 className="text-lg font-semibold mb-2">Delete Account?</h3>
              <p className="text-gray-400 text-sm mb-6">
                This action cannot be undone. All your data will be permanently deleted.
              </p>
              <div className="space-y-2">
                <button
                  onClick={() => setShowConfirmDelete(false)}
                  className="w-full py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
                >
                  Yes, Delete My Account
                </button>
                <button
                  onClick={() => setShowConfirmDelete(false)}
                  className="w-full py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AppSettings;