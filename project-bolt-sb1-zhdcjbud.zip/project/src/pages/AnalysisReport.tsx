import React from 'react';
import { useNavigate } from 'react-router-dom';
import Navigation from '../components/Navigation';
import { BarChart3, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';

interface ImageAnalysis {
  view: string;
  quality: number;
  confidence: number;
  keyPoints: number;
  alignmentScore: number;
}

const AnalysisReport: React.FC = () => {
  const navigate = useNavigate();
  
  // Simulated analysis data
  const analyses: ImageAnalysis[] = [
    {
      view: 'Front',
      quality: 95,
      confidence: 98,
      keyPoints: 32,
      alignmentScore: 92
    },
    {
      view: 'Side',
      quality: 90,
      confidence: 95,
      keyPoints: 28,
      alignmentScore: 88
    },
    {
      view: 'Back',
      quality: 92,
      confidence: 96,
      keyPoints: 30,
      alignmentScore: 90
    }
  ];

  const averages = {
    quality: analyses.reduce((acc, curr) => acc + curr.quality, 0) / analyses.length,
    confidence: analyses.reduce((acc, curr) => acc + curr.confidence, 0) / analyses.length,
    keyPoints: analyses.reduce((acc, curr) => acc + curr.keyPoints, 0) / analyses.length,
    alignmentScore: analyses.reduce((acc, curr) => acc + curr.alignmentScore, 0) / analyses.length
  };

  const getQualityColor = (value: number) => {
    if (value >= 90) return 'text-green-500';
    if (value >= 80) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        <header className="p-4 border-b border-gray-800">
          <h1 className="text-2xl font-bold">Analysis Report</h1>
          <p className="text-sm text-gray-400 mt-1">
            Comprehensive analysis of captured images
          </p>
        </header>

        <main className="p-4 space-y-6">
          {/* Summary Stats */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-900 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <BarChart3 className="w-5 h-5 text-blue-400" />
                <span className="text-sm text-gray-400">Total Images</span>
              </div>
              <p className="text-2xl font-bold">3</p>
            </div>
            <div className="bg-gray-900 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="w-5 h-5 text-green-400" />
                <span className="text-sm text-gray-400">Avg. Quality</span>
              </div>
              <p className="text-2xl font-bold">{averages.quality.toFixed(1)}%</p>
            </div>
          </div>

          {/* Per-View Analysis */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold">Image Analysis</h2>
            {analyses.map((analysis) => (
              <div key={analysis.view} className="bg-gray-900 rounded-lg p-4">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-medium">{analysis.view} View</h3>
                  <span className={`text-sm ${getQualityColor(analysis.quality)}`}>
                    {analysis.quality}% Quality
                  </span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Confidence</span>
                    <span>{analysis.confidence}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Key Points</span>
                    <span>{analysis.keyPoints}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Alignment</span>
                    <span>{analysis.alignmentScore}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Findings */}
          <div className="bg-gray-900 rounded-lg p-4">
            <h2 className="text-lg font-semibold mb-3">Key Findings</h2>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-300">
                  Slight posture misalignment detected in side view (12° deviation)
                </p>
              </div>
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-300">
                  Symmetrical movement patterns observed in front view
                </p>
              </div>
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-300">
                  Range of motion within normal parameters
                </p>
              </div>
            </div>
          </div>
        </main>

        <div className="fixed bottom-16 left-1/2 transform -translate-x-1/2 px-4 space-y-2" style={{ width: '390px' }}>
          <button
            onClick={() => navigate('/exercises')}
            className="w-full py-2.5 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition-colors flex items-center justify-center gap-2"
          >
            View Recommended Exercises
            <ArrowRight className="w-5 h-5" />
          </button>
          <button
            onClick={() => navigate('/camera')}
            className="w-full py-2.5 bg-white/10 text-white font-medium rounded-lg hover:bg-white/20 transition-colors"
          >
            Retake Images
          </button>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default AnalysisReport;