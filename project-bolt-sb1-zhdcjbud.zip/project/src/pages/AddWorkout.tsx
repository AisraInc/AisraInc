import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Timer, Flame, ChevronRight } from 'lucide-react';
import Navigation from '../components/Navigation';

const AddWorkout: React.FC = () => {
  const navigate = useNavigate();

  const workouts = [
    {
      title: 'Workout 1',
      areas: 'Shoulder (R), Knee (L)',
      duration: '30 min',
      calories: '442 kcal',
      image: 'https://images.unsplash.com/photo-1576678927484-cc907957088c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'
    },
    {
      title: 'Workout 2',
      areas: 'Shoulders, Knees',
      duration: '45 min',
      calories: '550 kcal',
      image: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'
    },
    {
      title: 'Workout 3',
      areas: 'Knees',
      duration: '25 min',
      calories: '320 kcal',
      image: 'https://images.unsplash.com/photo-1517637382994-f02da38c6728?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80'
    }
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto bg-black min-h-screen relative pb-16 text-white">
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-2xl font-bold">30 Day Personalized Programs</h1>
            <p className="text-sm text-gray-400">Week #1</p>
          </div>
        </header>

        {/* Workouts List */}
        <main className="p-4 space-y-4">
          {workouts.map((workout, index) => (
            <div 
              key={index}
              className="relative h-48 rounded-xl overflow-hidden cursor-pointer group"
              onClick={() => navigate(`/workout/${index + 1}`)}
            >
              <img
                src={workout.image}
                alt={workout.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent group-hover:from-black/90 transition-colors">
                <div className="absolute bottom-0 p-4 w-full">
                  <div className="flex justify-between items-end">
                    <div className="space-y-1">
                      <h3 className="text-xl font-semibold">{workout.title}</h3>
                      <p className="text-sm text-gray-300">{workout.areas}</p>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1">
                          <Timer className="w-4 h-4 text-blue-400" />
                          <span className="text-sm">{workout.duration}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Flame className="w-4 h-4 text-orange-400" />
                          <span className="text-sm">{workout.calories}</span>
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="w-6 h-6" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </main>

        <Navigation />
      </div>
    </div>
  );
};

export default AddWorkout;