import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Navigation from '../components/Navigation';

const Exercises: React.FC = () => {
  const navigate = useNavigate();

  const exerciseSets = [
    {
      setNumber: 1,
      exercises: [
        { name: 'Shoulder Touch (Rt)', reps: 10 },
        { name: 'Shoulder Touch (Lt)', reps: 10 },
        { name: 'Arm Circles', reps: 12 },
        { name: 'Arm Circles (Front)', reps: 12 },
        { name: 'Lateral Raises', reps: 12 }
      ]
    },
    {
      setNumber: 2,
      exercises: [
        { name: 'Shoulder Touch (Rt)', reps: 15 },
        { name: 'Shoulder Touch (Lt)', reps: 12 },
        { name: 'Arm Circles', reps: 12 },
        { name: 'Arm Circles (Front)', reps: 12 },
        { name: 'Lateral Raises', reps: 12 }
      ]
    },
    {
      setNumber: 3,
      exercises: [
        { name: 'Shoulder Touch (Rt)', reps: 12 },
        { name: 'Shoulder Touch (Lt)', reps: 12 },
        { name: 'Arm Circles', reps: 12 },
        { name: 'Arm Circles (Front)', reps: 12 },
        { name: 'Lateral Raises', reps: 12 }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        <header className="p-6 space-y-4">
          <h1 className="text-3xl font-medium">Exercises</h1>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-white">Areas of Focus:</span>
              <span>Shoulders</span>
            </div>
          </div>
        </header>

        <main className="px-6 pb-24 space-y-8">
          {/* Equipment Selection */}
          <div>
            <p className="text-base text-white mb-2">Equipment</p>
            <div className="flex gap-2 w-full">
              <button 
                className="h-[38px] px-[6px] rounded-[25px] text-base bg-black text-[#21E102] border-[2px] border-[#21E102] whitespace-nowrap"
                style={{ width: '109px' }}
              >
                Body Weight
              </button>
              <button 
                className="h-[38px] px-[10px] rounded-[25px] text-base border-[2px] border-white/80 text-white whitespace-nowrap"
              >
                Resistance Bands
              </button>
              <button 
                className="h-[38px] px-[10px] rounded-[25px] text-base border-[2px] border-white/80 text-white whitespace-nowrap"
              >
                Weights
              </button>
            </div>
          </div>

          {/* Separator Line */}
          <div className="w-full h-px bg-gray-800" />

          {/* Time Selection */}
          <div className="-mt-2">
            <p className="text-base text-white mb-2">Time</p>
            <div className="flex gap-2 w-full">
              <button 
                className="h-[38px] px-[10px] rounded-[50px] text-base bg-black text-[#21E102] border-2 border-[#21E102] whitespace-nowrap"
              >
                15 min
              </button>
              <button 
                className="h-[38px] px-[10px] rounded-[50px] text-base border-2 border-white/80 text-white whitespace-nowrap"
              >
                10 min
              </button>
              <button 
                className="h-[38px] px-[10px] rounded-[50px] text-base border-2 border-white/80 text-white whitespace-nowrap"
              >
                5 min
              </button>
            </div>
          </div>

          {/* Exercise Sets */}
          {exerciseSets.map((set, index) => (
            <div key={index} className="space-y-4">
              <h2 className="text-2xl text-[#42ACF9]">Set {set.setNumber}</h2>
              <div className="grid grid-cols-[40px_1fr_40px] text-base text-white mb-2">
                <div className="text-center">#</div>
                <div className="text-center">Exercise</div>
                <div className="text-right">Reps</div>
              </div>
              <div className="space-y-3">
                {set.exercises.map((exercise, exIndex) => (
                  <div key={exIndex} className="grid grid-cols-[40px_1fr_40px] items-center">
                    <div className="w-10 h-10 bg-[#979090] flex items-center justify-center">
                      <span className="text-base">{exIndex + 1}</span>
                    </div>
                    <span className="text-[#42ACF9] text-base text-center">{exercise.name}</span>
                    <div className="w-10 h-10 bg-[#979090] flex items-center justify-center ml-auto">
                      <span className="text-base">{exercise.reps}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </main>

        {/* Bottom Buttons */}
        <div className="fixed bottom-16 left-0 right-0 p-4 space-y-2 bg-black" style={{ width: '390px', margin: '0 auto' }}>
          <button
            onClick={() => navigate('/timer')}
            className="w-full py-3.5 bg-[#42ACF9] text-white text-lg rounded-lg"
          >
            Start
          </button>
          <button
            onClick={() => navigate('/')}
            className="w-full py-3.5 bg-black text-white text-lg rounded-lg border border-white/20"
          >
            Back
          </button>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default Exercises;