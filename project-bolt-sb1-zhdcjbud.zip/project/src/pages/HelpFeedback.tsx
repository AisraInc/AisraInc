import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  ChevronDown, 
  MessageCircle, 
  Mail, 
  HelpCircle,
  Star,
  Send,
  FileText,
  AlertCircle,
  ChevronRight,
  ExternalLink
} from 'lucide-react';

const HelpFeedback: React.FC = () => {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [feedbackType, setFeedbackType] = useState<'bug' | 'feature' | 'general'>('general');
  const [feedbackText, setFeedbackText] = useState('');
  const [showFeedbackSuccess, setShowFeedbackSuccess] = useState(false);

  const faqs = [
    {
      id: '1',
      question: 'How do I track my workout progress?',
      answer: 'You can track your workout progress through the Dashboard. It shows your daily activities, completed workouts, and achievement statistics. You can also view detailed analytics in the Analysis section.'
    },
    {
      id: '2',
      question: 'Can I customize my workout plan?',
      answer: 'Yes! You can customize your workout plan in the Training Plans section. Select your preferred difficulty level, focus areas, and time commitment to get a personalized plan that fits your needs.'
    },
    {
      id: '3',
      question: 'How does the injury tracking work?',
      answer: 'Our injury tracking system uses the body map to pinpoint specific areas of concern. You can mark areas of discomfort, rate pain levels, and receive targeted recovery exercises.'
    },
    {
      id: '4',
      question: 'What should I do if the app crashes?',
      answer: 'If the app crashes, try clearing the cache in App Settings. If the issue persists, you can report the bug through our feedback system or contact support directly.'
    }
  ];

  const handleSubmitFeedback = () => {
    if (!feedbackText.trim()) return;
    
    // Simulate feedback submission
    setShowFeedbackSuccess(true);
    setTimeout(() => {
      setShowFeedbackSuccess(false);
      setFeedbackText('');
      setFeedbackType('general');
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Help & Feedback</h1>
        </header>

        <main className="p-4 space-y-6">
          {/* Quick Actions */}
          <section className="grid grid-cols-2 gap-4">
            <button className="p-4 bg-gray-900 rounded-xl hover:bg-gray-800 transition-colors text-left">
              <MessageCircle className="w-6 h-6 text-[#42ACF9] mb-2" />
              <h3 className="font-medium">Chat Support</h3>
              <p className="text-sm text-gray-400">24/7 Live Chat</p>
            </button>
            <button className="p-4 bg-gray-900 rounded-xl hover:bg-gray-800 transition-colors text-left">
              <Mail className="w-6 h-6 text-[#42ACF9] mb-2" />
              <h3 className="font-medium">Email Us</h3>
              <p className="text-sm text-gray-400">support@aisra.fit</p>
            </button>
          </section>

          {/* FAQs */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <HelpCircle className="w-5 h-5 text-[#42ACF9]" />
              Frequently Asked Questions
            </h2>
            <div className="space-y-3">
              {faqs.map((faq) => (
                <div key={faq.id} className="bg-gray-900 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setActiveSection(activeSection === faq.id ? null : faq.id)}
                    className="w-full p-4 flex items-center justify-between hover:bg-gray-800 transition-colors"
                  >
                    <span className="font-medium">{faq.question}</span>
                    <ChevronDown 
                      className={`w-5 h-5 text-gray-400 transition-transform ${
                        activeSection === faq.id ? 'rotate-180' : ''
                      }`}
                    />
                  </button>
                  {activeSection === faq.id && (
                    <div className="p-4 pt-0 text-gray-400 text-sm">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* Submit Feedback */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Star className="w-5 h-5 text-[#42ACF9]" />
              Submit Feedback
            </h2>
            <div className="bg-gray-900 rounded-xl p-4 space-y-4">
              <div className="space-y-2">
                <label className="text-sm text-gray-400">Feedback Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { value: 'bug', label: 'Bug Report' },
                    { value: 'feature', label: 'Feature Request' },
                    { value: 'general', label: 'General' }
                  ].map((type) => (
                    <button
                      key={type.value}
                      onClick={() => setFeedbackType(type.value as any)}
                      className={`py-2 px-3 rounded-lg text-sm font-medium transition-colors
                        ${feedbackType === type.value
                          ? 'bg-[#42ACF9] text-white'
                          : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
                        }`}
                    >
                      {type.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-gray-400">Your Feedback</label>
                <textarea
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  placeholder="Tell us what you think..."
                  className="w-full h-32 bg-gray-800 rounded-lg p-3 text-white placeholder-gray-500 resize-none focus:outline-none focus:ring-2 focus:ring-[#42ACF9]"
                />
              </div>
              <button
                onClick={handleSubmitFeedback}
                disabled={!feedbackText.trim()}
                className="w-full py-3 bg-[#42ACF9] text-white font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                Submit Feedback
              </button>
            </div>
          </section>

          {/* Additional Resources */}
          <section>
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#42ACF9]" />
              Resources
            </h2>
            <div className="space-y-3">
              <a 
                href="#" 
                className="block p-4 bg-gray-900 rounded-xl hover:bg-gray-800 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="w-5 h-5 text-gray-400" />
                    <span>User Guide</span>
                  </div>
                  <ExternalLink className="w-5 h-5 text-gray-400" />
                </div>
              </a>
              <a 
                href="#" 
                className="block p-4 bg-gray-900 rounded-xl hover:bg-gray-800 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <AlertCircle className="w-5 h-5 text-gray-400" />
                    <span>Privacy Policy</span>
                  </div>
                  <ExternalLink className="w-5 h-5 text-gray-400" />
                </div>
              </a>
            </div>
          </section>
        </main>

        {/* Feedback Success Message */}
        {showFeedbackSuccess && (
          <div className="fixed bottom-20 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-4 py-2 rounded-lg animate-fade-in">
            Feedback submitted successfully!
          </div>
        )}
      </div>
    </div>
  );
};

export default HelpFeedback;