import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, RotateCw } from 'lucide-react';
import Navigation from '../components/Navigation';

const WorkoutComparison: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-xl font-bold">Programs</h1>
            <p className="text-sm text-gray-400">Week 1 • Day {id}</p>
          </div>
        </header>

        {/* Main Content */}
        <div className="p-4">
          <div className="aspect-[3/4] bg-gray-900 rounded-lg overflow-hidden relative">
            <div className="grid grid-cols-2 h-full">
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1594381898411-846e7d193883?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
                  alt="Target pose"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg width="100" height="200" viewBox="0 0 100 200" className="stroke-white/80">
                    <line x1="50" y1="25" x2="50" y2="75" strokeWidth="2" />
                    <line x1="50" y1="75" x2="25" y2="125" strokeWidth="2" />
                    <line x1="50" y1="75" x2="75" y2="125" strokeWidth="2" />
                    <line x1="50" y1="50" x2="25" y2="75" strokeWidth="2" />
                    <line x1="50" y1="50" x2="75" y2="75" strokeWidth="2" />
                    <circle cx="50" cy="25" r="10" fill="none" strokeWidth="2" />
                  </svg>
                </div>
              </div>
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1594381898411-846e7d193883?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
                  alt="Your pose"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <svg width="100" height="200" viewBox="0 0 100 200" className="stroke-[#42ACF9]">
                    <line x1="50" y1="25" x2="50" y2="75" strokeWidth="2" />
                    <line x1="50" y1="75" x2="25" y2="125" strokeWidth="2" />
                    <line x1="50" y1="75" x2="75" y2="125" strokeWidth="2" />
                    <line x1="50" y1="50" x2="25" y2="75" strokeWidth="2" />
                    <line x1="50" y1="50" x2="75" y2="75" strokeWidth="2" />
                    <circle cx="50" cy="25" r="10" fill="none" strokeWidth="2" />
                  </svg>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            <div className="bg-gray-900 rounded-lg p-4">
              <h2 className="text-lg font-semibold mb-2">Analysis Results</h2>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Pose Accuracy</span>
                  <span className="text-[#42ACF9]">92%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Balance</span>
                  <span className="text-[#42ACF9]">88%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Form Quality</span>
                  <span className="text-[#42ACF9]">95%</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => navigate('/exercises')}
              className="w-full py-3 bg-[#42ACF9] text-white font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors"
            >
              Continue to Exercises
            </button>

            <button
              onClick={() => navigate('/dashboard')}
              className="w-full py-3 bg-white/10 text-white font-medium rounded-lg hover:bg-white/20 transition-colors"
            >
              Return to Programs
            </button>
          </div>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default WorkoutComparison;