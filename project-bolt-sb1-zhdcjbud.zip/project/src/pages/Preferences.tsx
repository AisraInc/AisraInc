import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Bell, Volume2, Moon, Globe, Smartphone, Dumbbell, Clock } from 'lucide-react';

const Preferences: React.FC = () => {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState(true);
  const [sound, setSound] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [language, setLanguage] = useState('English');
  const [units, setUnits] = useState('Imperial');
  const [workoutDifficulty, setWorkoutDifficulty] = useState('Intermediate');
  const [restTime, setRestTime] = useState('60');

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setLanguage(e.target.value);
  };

  const handleUnitsChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setUnits(e.target.value);
  };

  const handleDifficultyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setWorkoutDifficulty(e.target.value);
  };

  const handleRestTimeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setRestTime(e.target.value);
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Preferences</h1>
        </header>

        <main className="p-4 space-y-6">
          {/* Notifications Section */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Notifications</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bell className="w-5 h-5 text-gray-400" />
                  <span>Push Notifications</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={notifications}
                    onChange={(e) => setNotifications(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#42ACF9]"></div>
                </label>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Volume2 className="w-5 h-5 text-gray-400" />
                  <span>Sound Effects</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={sound}
                    onChange={(e) => setSound(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#42ACF9]"></div>
                </label>
              </div>
            </div>
          </section>

          {/* Display Section */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Display</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Moon className="w-5 h-5 text-gray-400" />
                  <span>Dark Mode</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={darkMode}
                    onChange={(e) => setDarkMode(e.target.checked)}
                  />
                  <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#42ACF9]"></div>
                </label>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Globe className="w-5 h-5 text-gray-400" />
                  <span>Language</span>
                </div>
                <select
                  value={language}
                  onChange={handleLanguageChange}
                  className="bg-gray-800 text-white rounded-lg px-3 py-2 outline-none"
                >
                  <option value="English">English</option>
                  <option value="Spanish">Spanish</option>
                  <option value="French">French</option>
                  <option value="German">German</option>
                </select>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Smartphone className="w-5 h-5 text-gray-400" />
                  <span>Units</span>
                </div>
                <select
                  value={units}
                  onChange={handleUnitsChange}
                  className="bg-gray-800 text-white rounded-lg px-3 py-2 outline-none"
                >
                  <option value="Imperial">Imperial (lbs, ft)</option>
                  <option value="Metric">Metric (kg, m)</option>
                </select>
              </div>
            </div>
          </section>

          {/* Workout Preferences */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Workout Preferences</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Dumbbell className="w-5 h-5 text-gray-400" />
                  <span>Difficulty Level</span>
                </div>
                <select
                  value={workoutDifficulty}
                  onChange={handleDifficultyChange}
                  className="bg-gray-800 text-white rounded-lg px-3 py-2 outline-none"
                >
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-gray-400" />
                  <span>Rest Time</span>
                </div>
                <select
                  value={restTime}
                  onChange={handleRestTimeChange}
                  className="bg-gray-800 text-white rounded-lg px-3 py-2 outline-none"
                >
                  <option value="30">30 seconds</option>
                  <option value="45">45 seconds</option>
                  <option value="60">60 seconds</option>
                  <option value="90">90 seconds</option>
                </select>
              </div>
            </div>
          </section>

          {/* Save Button */}
          <button
            onClick={() => navigate(-1)}
            className="w-full py-3 bg-[#42ACF9] text-white font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors"
          >
            Save Changes
          </button>
        </main>
      </div>
    </div>
  );
};

export default Preferences;