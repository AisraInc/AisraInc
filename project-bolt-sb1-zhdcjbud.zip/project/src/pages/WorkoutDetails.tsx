import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Home } from 'lucide-react';
import Navigation from '../components/Navigation';

const WorkoutDetails: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();

  const exerciseSets = [
    {
      setNumber: 1,
      exercises: [
        { name: 'Shoulder Touch (Rt)', reps: 10 },
        { name: 'Shoulder Touch (Lt)', reps: 12 },
        { name: 'Arm Circles', reps: 12 },
        { name: 'Arm Circles (Front)', reps: 12 },
        { name: 'Lateral Raises', reps: 12 }
      ]
    },
    {
      setNumber: 2,
      exercises: [
        { name: 'Shoulder Touch (Rt)', reps: 15 },
        { name: 'Shoulder Touch (Lt)', reps: 12 },
        { name: 'Arm Circles', reps: 12 },
        { name: 'Arm Circles (Front)', reps: 12 },
        { name: 'Lateral Raises', reps: 12 }
      ]
    },
    {
      setNumber: 3,
      exercises: [
        { name: 'Shoulder Touch (Rt)', reps: 12 },
        { name: 'Shoulder Touch (Lt)', reps: 12 },
        { name: 'Arm Circles', reps: 12 },
        { name: 'Arm Circles (Front)', reps: 12 },
        { name: 'Lateral Raises', reps: 12 }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        <header className="p-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold mt-4">Exercises</h1>
          <p className="text-sm text-gray-400 mt-1">Areas of Focus: Shoulders</p>
        </header>

        <main className="px-4 pb-24">
          {/* Equipment Selection */}
          <div className="mb-6">
            <p className="text-sm text-gray-400 mb-2">Equipment</p>
            <div className="flex gap-2">
              <button className="px-4 py-2 rounded-full text-sm bg-[#21E102] text-black">
                Body Weight
              </button>
              <button className="px-4 py-2 rounded-full text-sm bg-gray-800 text-white">
                Resistance Bands
              </button>
              <button className="px-4 py-2 rounded-full text-sm bg-gray-800 text-white">
                Weights
              </button>
            </div>
          </div>

          {/* Time Selection */}
          <div className="mb-6">
            <p className="text-sm text-gray-400 mb-2">Time</p>
            <div className="flex gap-2">
              <button className="px-4 py-2 rounded-full text-sm bg-[#21E102] text-black">
                15 min
              </button>
              <button className="px-4 py-2 rounded-full text-sm bg-gray-800 text-white">
                10 min
              </button>
              <button className="px-4 py-2 rounded-full text-sm bg-gray-800 text-white">
                5 min
              </button>
            </div>
          </div>

          {/* Exercise Sets */}
          {exerciseSets.map((set, index) => (
            <div key={index} className="mb-8">
              <h2 className="text-lg font-medium mb-4">Set {set.setNumber}</h2>
              <div className="space-y-2">
                {set.exercises.map((exercise, exIndex) => (
                  <div key={exIndex} className="bg-gray-800 rounded-lg p-4 flex justify-between items-center">
                    <div className="flex items-center gap-4">
                      <span className="text-gray-400">{exIndex + 1}</span>
                      <span className="text-[#42ACF9]">{exercise.name}</span>
                    </div>
                    <span>{exercise.reps}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </main>

        {/* Bottom Buttons */}
        <div className="fixed bottom-0 left-0 right-0 p-4 space-y-2 bg-black" style={{ width: '390px', margin: '0 auto' }}>
          <button
            onClick={() => navigate('/timer')}
            className="w-full py-3 bg-[#42ACF9] text-white font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors"
          >
            Start
          </button>
          <button
            onClick={() => navigate('/')}
            className="w-full py-3 bg-gray-800 text-white font-medium rounded-lg hover:bg-gray-700 transition-colors"
          >
            Back
          </button>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default WorkoutDetails;