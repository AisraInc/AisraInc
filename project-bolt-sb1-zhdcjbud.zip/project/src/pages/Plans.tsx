import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Calendar, Trophy, Timer, Dumbbell, ChevronRight, Star, BarChart } from 'lucide-react';

const Plans: React.FC = () => {
  const navigate = useNavigate();

  const activePlan = {
    name: '30-Day Recovery',
    progress: 65,
    daysCompleted: 19,
    totalDays: 30,
    nextWorkout: 'Upper Body Strength',
    timeLeft: '2 days',
  };

  const availablePlans = [
    {
      name: 'Strength Builder',
      duration: '8 weeks',
      level: 'Intermediate',
      rating: 4.8,
      reviews: 2453,
      image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80'
    },
    {
      name: 'Flexibility Master',
      duration: '6 weeks',
      level: 'Beginner',
      rating: 4.9,
      reviews: 1876,
      image: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80'
    },
    {
      name: 'Core Power',
      duration: '4 weeks',
      level: 'Advanced',
      rating: 4.7,
      reviews: 3241,
      image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80'
    },
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Training Plans</h1>
        </header>

        <main className="p-4 space-y-6">
          {/* Active Plan */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Current Plan</h2>
            <div className="bg-gray-900 rounded-xl p-4">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-medium">{activePlan.name}</h3>
                  <p className="text-sm text-gray-400">
                    {activePlan.daysCompleted} of {activePlan.totalDays} days completed
                  </p>
                </div>
                <div className="flex items-center gap-1 bg-[#42ACF9]/20 text-[#42ACF9] px-2 py-1 rounded-full text-sm">
                  <Calendar className="w-4 h-4" />
                  <span>Active</span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-gray-800 rounded-full h-2 mb-4">
                <div 
                  className="h-2 rounded-full bg-gradient-to-r from-[#21E102] to-[#42ACF9]"
                  style={{ width: `${activePlan.progress}%` }}
                />
              </div>

              {/* Next Workout */}
              <div className="bg-gray-800 rounded-lg p-3 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Timer className="w-5 h-5 text-[#42ACF9]" />
                  <div>
                    <p className="text-sm font-medium">{activePlan.nextWorkout}</p>
                    <p className="text-xs text-gray-400">Next workout in {activePlan.timeLeft}</p>
                  </div>
                </div>
                <button 
                  onClick={() => navigate('/workout/1')}
                  className="p-2 hover:bg-gray-700 rounded-lg transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>
          </section>

          {/* Stats */}
          <section className="grid grid-cols-2 gap-4">
            <div className="bg-gray-900 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <span className="text-sm text-gray-400">Achievements</span>
              </div>
              <p className="text-2xl font-bold">12</p>
            </div>
            <div className="bg-gray-900 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-2">
                <BarChart className="w-5 h-5 text-[#42ACF9]" />
                <span className="text-sm text-gray-400">Total Workouts</span>
              </div>
              <p className="text-2xl font-bold">48</p>
            </div>
          </section>

          {/* Available Plans */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Available Plans</h2>
            <div className="space-y-4">
              {availablePlans.map((plan, index) => (
                <div key={index} className="bg-gray-900 rounded-xl overflow-hidden">
                  <img
                    src={plan.image}
                    alt={plan.name}
                    className="w-full h-32 object-cover"
                  />
                  <div className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-medium">{plan.name}</h3>
                        <div className="flex items-center gap-4 text-sm text-gray-400">
                          <span className="flex items-center gap-1">
                            <Timer className="w-4 h-4" />
                            {plan.duration}
                          </span>
                          <span className="flex items-center gap-1">
                            <Dumbbell className="w-4 h-4" />
                            {plan.level}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-yellow-400">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="text-sm">{plan.rating}</span>
                        <span className="text-xs text-gray-400">({plan.reviews})</span>
                      </div>
                    </div>
                    <button
                      onClick={() => navigate('/workout/1')}
                      className="w-full py-2 bg-[#42ACF9] text-white rounded-lg hover:bg-[#42ACF9]/90 transition-colors mt-2"
                    >
                      Start Plan
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
    </div>
  );
};

export default Plans;