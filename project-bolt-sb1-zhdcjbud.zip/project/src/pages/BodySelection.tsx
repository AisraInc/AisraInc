import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import BodyMap from '../components/BodyMap';
import Controls from '../components/Controls';
import Navigation from '../components/Navigation';
import ViewToggle from '../components/ViewToggle';
import { bodyParts } from '../data/bodyParts';
import InjuryIndicator from '../components/InjuryIndicator';
import PainLevelModal from '../components/PainLevelModal';
import { PainPoint, PainDetails } from '../types';

const BodySelection: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedParts, setSelectedParts] = useState<string[]>([]);
  const [painPoints, setPainPoints] = useState<PainPoint[]>([]);
  const [view, setView] = useState<'front' | 'back'>('front');
  const [zoom, setZoom] = useState(1);
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    activePart: string | null;
    coordinates: { x: number; y: number } | null;
  }>({ isOpen: false, activePart: null, coordinates: null });

  const bodyImageUrl = "https://s3-alpha-sig.figma.com/img/24c8/e6c0/6989d6b032810af2c2101cb2f14af667?Expires=1740355200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=ZI3Im8AafpF2EzPKzKCTnDG9k6S~phf8ZgLNTIfL~HF5xc9OOiWee10M0lww0UoltuHk6dIVeeSvGCaU9yaTRwmeOoT-hOax-wLZXR3j5ACzwNeE48TPZOYIW94qIrQaZ0qVjzyYMjNwTmsxzXvPRJvEeWpMsYETFDbyAZWIzKlbeh-hCj0d5MmN3UlEEShRfeda3xnW7xvLIXnTLJ4a6ZzNe3vGHODisv29rPcTOLKcf7hOv8yBNha3cswl5~b9sPA6OPpDSZCbpH4XD69vrLv8Ings3m9tcTJ~6NiS9h~CCT1-YoI8qTuMjR2a~n1PwqMr5aFqTWnMMlsnIWdtBA__";

  const handleTogglePart = (partId: string) => {
    // Only allow one selection at a time
    setSelectedParts([partId]);
  };

  // Load saved pain points from localStorage on mount
  useEffect(() => {
    const savedPoints = localStorage.getItem('painPoints');
    const points = savedPoints ? JSON.parse(savedPoints) : [];
    
    // Check if we're in edit mode
    const editState = location.state as { editPartId?: string } | null;
    if (editState?.editPartId) {
      // If editing, only select the part being edited
      const editPoint = points.find(p => p.partId === editState.editPartId);
      if (editPoint) {
        setPainPoints([editPoint]);
        setSelectedParts([editState.editPartId]);
      }
    } else {
      // Normal load of all points
      setPainPoints(points);
      setSelectedParts(points.map((p: PainPoint) => p.partId));
    }
  }, [location]);

  // Save pain points to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('painPoints', JSON.stringify(painPoints));
  }, [painPoints]);

  const handleRemovePart = (partId: string) => {
    setSelectedParts(prev => prev.filter(id => id !== partId));
    setPainPoints(prev => prev.filter(point => point.partId !== partId));
  };
  
  const handleOpenModal = (partId: string, coordinates: { x: number; y: number }) => {
    setModalState({ isOpen: true, activePart: partId, coordinates });
  };

  const handleCloseModal = () => {
    setModalState({ isOpen: false, activePart: null, coordinates: null });
  };

  const handlePainConfirm = (details: PainDetails) => {
    if (modalState.activePart && modalState.coordinates) {
      const editState = location.state as { editPartId?: string } | null;
      setPainPoints(prev => {
        const savedPoints = localStorage.getItem('painPoints');
        const allPoints = savedPoints ? JSON.parse(savedPoints) : [];
        
        const newPoint: PainPoint = {
          partId: modalState.activePart,
          coordinates: modalState.coordinates,
          details
        };

        if (editState?.editPartId) {
          // Update the specific point in all saved points
          const updatedPoints = allPoints.map((p: PainPoint) => 
            p.partId === editState.editPartId ? newPoint : p
          );
          localStorage.setItem('painPoints', JSON.stringify(updatedPoints));
          navigate('/summary');
          return [newPoint];
        } else {
          // Add new point
          const updatedPoints = [...allPoints, newPoint];
          localStorage.setItem('painPoints', JSON.stringify(updatedPoints));
          return [...prev, newPoint];
        }
      });
    }
    handleCloseModal();
  };

  const isReadyToProceed = selectedParts.length === 1;

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.1, 2));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.1, 0.5));
  const handleReset = () => setZoom(1);

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto bg-white min-h-screen relative pb-16">
        <header className="p-4 flex items-center justify-between border-b border-gray-200">
          <div>
            <h1 className="text-2xl font-bold">Body Analysis</h1>
            <p className="text-sm text-gray-600 mt-1">
              Select the area that needs attention
            </p>
          </div>
        </header>

        {painPoints.map((point, index) => {
          const part = bodyParts.find(p => p.id === point.partId);
          if (!part) return null;
          return (
            <InjuryIndicator
              key={point.partId}
              label={part.label}
              onRemove={() => handleRemovePart(point.partId)}
              painLevel={point.details.level}
              position={index}
            />
          );
        })}

        <main className="relative h-[calc(100vh-12rem)]">
          <BodyMap
            selectedParts={selectedParts}
            onTogglePart={handleTogglePart}
            onPartClick={handleOpenModal}
            view={view}
            zoom={zoom}
          />
          <Controls
            onZoomIn={handleZoomIn}
            onZoomOut={handleZoomOut}
            onReset={handleReset}
          />
          <ViewToggle view={view} onViewChange={setView} />
        </main>

        <button 
          className={`absolute bottom-20 left-4 right-4 py-3 rounded-lg font-medium transition-colors
            ${isReadyToProceed 
              ? 'bg-blue-500 text-white hover:bg-blue-600' 
              : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
          disabled={!isReadyToProceed}
          onClick={() => {
            if (isReadyToProceed) {
              navigate('/summary');
            }
          }}
        >
          Save & Continue
        </button>
        
        {modalState.isOpen && modalState.activePart && modalState.coordinates && (
          <PainLevelModal
            partLabel={bodyParts.find(p => p.id === modalState.activePart)?.label || ''}
            onClose={handleCloseModal}
            onConfirm={handlePainConfirm}
            initialDetails={painPoints.find(p => p.partId === modalState.activePart)?.details}
          />
        )}

        <Navigation />
      </div>
    </div>
  );
};

export default BodySelection;