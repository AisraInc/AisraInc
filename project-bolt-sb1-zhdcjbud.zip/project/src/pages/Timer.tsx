import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, RotateCw, Play, Pause, SkipBack, SkipForward, Award } from 'lucide-react';
import Navigation from '../components/Navigation';
import { motion, AnimatePresence } from 'framer-motion';

const APP_WIDTH = '390px'; // Standard iPhone width

const WORKOUT_COMPLETION_KEY = 'lastCompletedWorkout';
const FIRST_WORKOUT_KEY = 'firstWorkoutCompleted';

const Timer: React.FC = () => {
  const navigate = useNavigate();
  const [isPlaying, setIsPlaying] = useState(true);
  const [isCompleted, setIsCompleted] = useState(false);
  const [progress, setProgress] = useState(0);
  const [currentExercise, setCurrentExercise] = useState(1);
  const [showCompletionPopup, setShowCompletionPopup] = useState(false);
  const playerRef = useRef<HTMLIFrameElement>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [showVideo, setShowVideo] = useState(true);
  const [showCountdown, setShowCountdown] = useState(false);
  const [countdownNumber, setCountdownNumber] = useState(3);
  const [player, setPlayer] = useState<any>(null);
  const [showCamera, setShowCamera] = useState(false);
  const [showStartButton, setShowStartButton] = useState(false);
  const [exerciseCount, setExerciseCount] = useState(10);

  const exercises = [
    {
      number: 1,
      set: 1,
      name: 'Shoulder Touch (Right)',
      instructions: [
        'Start in athletic stance - Feet hip-width apart, knees slightly bent, core engaged.',
        'Touch opposite shoulder - Lift one hand, tap the opposite shoulder, and return.',
        'Minimize torso movement - Keep hips and core stable, avoiding sway.',
        'Controlled repetitions - Perform 10 reps on your right side.'
      ]
    },
    {
      number: 2,
      set: 2,
      name: 'Shoulder Touch (Left)',
      instructions: [
        'Start in athletic stance - Feet hip-width apart, knees slightly bent, core engaged.',
        'Touch opposite shoulder - Lift one hand, tap the opposite shoulder, and return.',
        'Minimize torso movement - Keep hips and core stable, avoiding sway.',
        'Controlled repetitions - Perform 10 reps on your left side.'
      ]
    },
    {
      number: 3,
      set: 3,
      name: 'Lateral Raises',
      instructions: [
        'Start position - Stand tall, feet hip-width apart, core engaged, arms at your sides.',
        'Lift arms to the side - Raise both arms to shoulder height with a slight bend in the elbows.',
        'Control the movement - Pause briefly at the top, then slowly lower back down.',
        'Avoid swinging - Keep movements smooth and controlled, engaging the shoulders.'
      ]
    }
  ];

  // Initialize YouTube Player
  useEffect(() => {
    // Load YouTube API
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);

    // Initialize player when API is ready
    window.onYouTubeIframeAPIReady = () => {
      const newPlayer = new window.YT.Player('youtube-player', {
        videoId: 'RyWlntngxKU',
        playerVars: {
          enablejsapi: 1,
          origin: window.location.origin,
          controls: 1,
          modestbranding: 1,
        },
        events: {
          onStateChange: (event: any) => {
            if (event.data === window.YT.PlayerState.ENDED) {
              setShowStartButton(true);
              setIsPlaying(false);
            }
          }
        }
      });
      setPlayer(newPlayer);
    };

    return () => {
      if (player) {
        player.destroy();
      }
    };
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying && progress < 100) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            setIsCompleted(true);
            setIsPlaying(false);
            // When video ends, show countdown then camera
            if (showVideo) {
              setShowVideo(false);
              setShowCountdown(true);
              startCountdown();
            } else if (showCamera) {
              setExerciseCount(prev => {
                if (prev > 1) {
                  return prev - 1;
                } else {
                  if (currentExercise < exercises.length) {
                    setCurrentExercise(prev => prev + 1);
                    setShowVideo(true);
                    setShowCamera(false);
                    setExerciseCount(10);
                  }
                  return 10;
                }
              });
              setProgress(0);
              setIsPlaying(true);
            }
            return 100;
          }
          return prev + 1;
        });
      }, 300);
    }
    return () => clearInterval(interval);
  }, [isPlaying, progress, currentExercise, showVideo, showCamera]);

  const startCountdown = () => {
    let count = 3;
    const countInterval = setInterval(() => {
      if (count > 1) {
        setCountdownNumber(count - 1);
        count--;
      } else {
        clearInterval(countInterval);
        setShowCountdown(false);
        // After countdown ends, show camera view
        setShowCamera(true);
        setProgress(0);
        setIsPlaying(true);
      }
    }, 1000);
  };

  const currentExerciseData = exercises[currentExercise - 1];

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    try {
      const player = playerRef.current;
      if (player?.contentWindow) {
        player.contentWindow.postMessage(
          JSON.stringify({
            event: 'command',
            func: isPlaying ? 'pauseVideo' : 'playVideo'
          }),
          '*'
        );
      }
    } catch (error) {
      console.error('Error controlling video:', error);
    }
  };

  const handleRestart = () => {
    setProgress(0);
    setIsPlaying(true);
  };

  const handleSkipForward = () => {
    if (currentExercise < exercises.length) {
      setIsTransitioning(true);
      setIsPlaying(false);
      setTimeout(() => {
        setCurrentExercise(prev => prev + 1);
        setProgress(0);
        setIsPlaying(true);
        setIsTransitioning(false);
      }, 1000);
    }
  };

  const handleSkipBack = () => {
    if (currentExercise > 1) {
      setIsTransitioning(true);
      setIsPlaying(false);
      setTimeout(() => {
        setCurrentExercise(prev => prev - 1);
        setProgress(0);
        setIsPlaying(true);
        setIsTransitioning(false);
      }, 1000);
    }
  };

  const handleShare = (platform: string) => {
    // In a real app, implement sharing functionality
    console.log(`Sharing to ${platform}`);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="mx-auto min-h-screen relative pb-16" style={{ width: APP_WIDTH }}>
        <header className="p-4 border-b border-gray-800">
          <h1 className="text-xl">Exercises</h1>
          <div>
            <p className="text-sm text-gray-400">Areas of Focus: Shoulders</p>
            <p className="text-sm text-gray-400">Equipment: Body Weight</p>
            <p className="text-sm text-gray-400">Time: 15 Minutes</p>
          </div>
        </header>

        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <span>Set {currentExerciseData.set}</span>
              <span className="text-gray-400">No. {currentExerciseData.number}</span>
            </div>
            <span className="text-[#42ACF9]">{currentExerciseData.name}</span>
          </div>

          {/* Video Player Box */}
          {showVideo && (
          <div className="aspect-video bg-gray-900 rounded-lg mb-6 overflow-hidden relative">
            <div
              id="youtube-player"
              className="w-full h-full"
            />
            {showStartButton && (
              <div className="absolute inset-0 bg-black/80 flex items-center justify-center animate-fade-in">
                <button
                  onClick={() => {
                    setShowVideo(false);
                    setShowCountdown(true);
                    startCountdown();
                  }}
                  className="px-8 py-4 bg-[#42ACF9] text-white text-lg font-medium rounded-xl hover:bg-[#42ACF9]/90 transition-colors"
                >
                  Start Exercise
                </button>
              </div>
            )}
          </div>
          )}

          {/* Camera View */}
          {showCamera && (
            <div className="aspect-video bg-black rounded-lg mb-6 relative overflow-hidden">
              {/* Camera Background */}
              <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-black" />
              
              {/* Exercise Counter */}
              <div className="absolute top-4 left-4 text-[120px] font-bold text-white opacity-90">
                {exerciseCount}
              </div>
              
              {/* Skeleton Overlay */}
              <div className="absolute inset-0 flex items-center justify-center">
                <svg className="w-full h-full max-w-[300px]" viewBox="0 0 100 200">
                  <g className="opacity-80">
                    <line x1="50" y1="25" x2="50" y2="75" stroke="white" strokeWidth="2" />
                    <line x1="50" y1="75" x2="25" y2="125" stroke="white" strokeWidth="2" />
                    <line x1="50" y1="75" x2="75" y2="125" stroke="white" strokeWidth="2" />
                    <line x1="50" y1="50" x2="25" y2="75" stroke="white" strokeWidth="2" />
                    <line x1="50" y1="50" x2="75" y2="75" stroke="white" strokeWidth="2" />
                    <circle cx="50" cy="25" r="10" stroke="white" strokeWidth="2" fill="none" />
                    {/* Joint points */}
                    <circle cx="50" cy="25" r="3" fill="white" />
                    <circle cx="50" cy="50" r="3" fill="white" />
                    <circle cx="50" cy="75" r="3" fill="white" />
                    <circle cx="25" cy="75" r="3" fill="white" />
                    <circle cx="75" cy="75" r="3" fill="white" />
                    <circle cx="25" cy="125" r="3" fill="white" />
                    <circle cx="75" cy="125" r="3" fill="white" />
                  </g>
                </svg>
              </div>
              
              {/* Exercise Name Overlay */}
              <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                <span className="text-lg font-medium">{currentExerciseData.name}</span>
                <span className="text-[#42ACF9]">Set {currentExerciseData.set}</span>
              </div>
            </div>
          )}
          <div className="flex items-center justify-center gap-8 mb-6">
            <div className="flex items-center gap-8">
              <button 
                onClick={handleSkipBack}
                disabled={currentExercise === 1}
                className={`p-2 transition-opacity ${
                  currentExercise === 1 ? 'opacity-50 cursor-not-allowed' : 'hover:text-white'
                }`}
              >
                <SkipBack className="w-8 h-8 text-gray-400" />
              </button>
              <button 
                onClick={handlePlayPause}
                className="w-16 h-16 rounded-full border-2 border-gray-400 flex items-center justify-center hover:bg-gray-800/50 transition-colors"
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8" />
                ) : (
                  <Play className="w-8 h-8 ml-1" />
                )}
              </button>
              <button 
                onClick={handleSkipForward}
                disabled={currentExercise === exercises.length}
                className={`p-2 transition-opacity ${
                  currentExercise === exercises.length ? 'opacity-50 cursor-not-allowed' : 'hover:text-white'
                }`}
              >
                <SkipForward className="w-8 h-8 text-gray-400" />
              </button>
            </div>
          </div>

          {/* Instructions List */}
          <h2 className="text-lg mb-3">Instructions</h2>
          <ul className="space-y-4 text-sm text-gray-300">
            {currentExerciseData.instructions.map((instruction, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-[#42ACF9] mt-1">•</span>
                {instruction}
              </li>
            ))}
          </ul>
        </div>

        {/* Exit Button */}
        <div className="fixed bottom-16 left-0 right-0 p-4" style={{ width: APP_WIDTH, margin: '0 auto' }}>
          <button
            onClick={() => {
              if (currentExercise === exercises.length) {
                // Store completion data
                const completionData = {
                  timestamp: new Date().toISOString(),
                  isFirstWorkout: true,
                  day: 'Sun', // For demo, always marks Sunday
                  totalPoints: 165 // Set initial points that will be confirmed in ExercisePoints
                };
                localStorage.setItem(WORKOUT_COMPLETION_KEY, JSON.stringify(completionData));
                
                // Show completion popup
                setShowCompletionPopup(true);
                                
                // Redirect after delay
                setTimeout(() => {
                  navigate('/exercise-points');
                }, 3000);
              } else {
                navigate('/exercise-points');
              }
            }}
            className={`w-full py-3 ${
              currentExercise === exercises.length 
                ? 'bg-[#42ACF9] hover:bg-[#42ACF9]/90'
                : 'bg-gray-800 hover:bg-gray-700'
            } text-white font-medium rounded-lg transition-colors text-sm`}
          >
            {currentExercise === exercises.length ? 'Complete Workout' : 'Exit'}
          </button>
        </div>

        {/* Exercise Complete Overlay */}
        {(isCompleted || isTransitioning) && currentExercise < exercises.length && (
          <div className="fixed inset-0 bg-black/90 flex items-center justify-center animate-fade-in">
            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4">Exercise Complete!</h2>
              <p className="text-gray-400 mb-6">Get ready for the next exercise</p>
              <div className="animate-pulse">
                <div className="w-16 h-16 rounded-full border-4 border-[#42ACF9] mx-auto" />
              </div>
            </div>
          </div>
        )}
        <Navigation />
      </div>
      
      {/* Exercise Countdown Overlay */}
      {showCountdown && (
        <div className="fixed inset-0 bg-black flex items-center justify-center z-50 animate-fade-in">
          <div className="w-full max-w-md mx-auto px-4 text-center">
            <h1 className="text-xl mb-4">Exercises</h1>
            <div className="mb-4">
              <p className="text-sm text-gray-400">Areas of Focus: Shoulders</p>
              <p className="text-sm text-gray-400">Equipment: Body Weight</p>
              <p className="text-sm text-gray-400">Time: 15 Minutes</p>
            </div>
            <div className="flex items-center justify-center gap-4 mb-8">
              <span className="text-[#42ACF9]">Set {currentExerciseData.set}</span>
              <span className="text-gray-400">Exercise {currentExerciseData.number}</span>
            </div>
            <p className="text-lg mb-8">Your Turn In...</p>
            <div className="text-[200px] font-bold text-white animate-countdown">
              {countdownNumber}
            </div>
            <div className="mt-8">
              <p className="text-gray-400">{currentExerciseData.name}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Workout Completion Popup */}
      <AnimatePresence>
        {showCompletionPopup && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 bg-black/80 flex items-center justify-center z-50"
          >
            <div className="bg-gray-900 rounded-2xl p-8 text-center max-w-sm mx-4">
              <div className="w-20 h-20 bg-[#42ACF9] rounded-full flex items-center justify-center mx-auto mb-6">
                <Award className="w-12 h-12 text-white" />
              </div>
              <h2 className="text-2xl font-bold mb-2">Workout Complete!</h2>
              <p className="text-gray-400 mb-6">
                Great job! You've completed all exercises for today.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Timer;