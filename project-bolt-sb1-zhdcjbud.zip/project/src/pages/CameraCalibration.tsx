import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, ArrowLeft } from 'lucide-react';
import Navigation from '../components/Navigation';

const CameraCalibration: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto bg-white min-h-screen relative pb-16">
        <header className="p-4 border-b border-gray-200">
          <h1 className="text-2xl font-bold">Camera Calibration</h1>
          <p className="text-sm text-gray-600 mt-1">
            To enhance your personalized experience, we kindly request a few photos of you.
            Please follow these simple steps:
          </p>
        </header>

        <main className="p-4">
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-lg">
                <span className="text-xl font-bold text-blue-500">1</span>
              </div>
              <div>
                <h3 className="font-medium">Place your camera forward</h3>
                <p className="text-sm text-gray-600 mt-1">
                  facing on the seat of a chair with the phone standing upright.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-lg">
                <span className="text-xl font-bold text-blue-500">2</span>
              </div>
              <div>
                <h3 className="font-medium">Stand about 10 feet away</h3>
                <p className="text-sm text-gray-600 mt-1">
                  or until the camera screen can view your whole body.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 flex items-center justify-center bg-blue-100 rounded-lg">
                <span className="text-xl font-bold text-blue-500">3</span>
              </div>
              <div>
                <h3 className="font-medium">Capture clear and well-lit photos</h3>
                <p className="text-sm text-gray-600 mt-1">
                  of your whole body and continue with both sides and back.
                </p>
              </div>
            </div>

            <div className="mt-8 p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-600">
                Rest assured, these photos will only be used for the sole purpose of customizing your
                experience. Your privacy and comfort are our top priorities.
              </p>
              <p className="text-sm text-gray-600 mt-2 font-medium">
                Thank you - The Aisra Team
              </p>
            </div>
          </div>
        </main>

        <div className="fixed bottom-16 left-1/2 transform -translate-x-1/2 w-full max-w-md px-4 space-y-2">
          <button
            onClick={() => navigate('/camera')}
            className="relative w-full py-3 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition-colors"
          >
            <Camera className="absolute left-4 w-5 h-5" />
            Get Started
          </button>
          <button
            onClick={() => navigate('/summary')}
            className="relative w-full py-3 bg-white/10 text-white font-medium rounded-lg hover:bg-white/20 transition-colors"
          >
            <ArrowLeft className="absolute left-4 w-5 h-5" />
            Return to Programs
          </button>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default CameraCalibration;