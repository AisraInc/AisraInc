import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera as CameraIcon, RotateCcw, Circle } from 'lucide-react';
import Navigation from '../components/Navigation';

const Camera: React.FC = () => {
  const navigate = useNavigate();
  const [view, setView] = useState<'front' | 'side' | 'back'>('front');
  const [isCountingDown, setIsCountingDown] = useState(false);
  const [countdown, setCountdown] = useState(5);
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isCountingDown && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
    } else if (isCountingDown && countdown === 0) {
      setIsCountingDown(false);
      setIsRecording(true);
      // Start recording for 3 seconds
      setTimeout(() => {
        setIsRecording(false);
        setIsAnalyzing(true);
        // Show analyzing state for 2 seconds
        setTimeout(() => {
          setIsAnalyzing(false);
          if (view === 'front') {
            setView('side');
          } else if (view === 'side') {
            setView('back');
          } else {
            navigate('/analysis');
          }
          setCountdown(5);
        }, 2000);
      }, 3000);
    }
    return () => clearTimeout(timer);
  }, [isCountingDown, countdown, view, navigate]);

  const getViewLabel = () => {
    switch (view) {
      case 'front':
        return 'Front Image';
      case 'side':
        return 'Side View';
      case 'back':
        return 'Back View';
    }
  };

  const handleStartRecording = () => {
    if (!isRecording && !isCountingDown) {
      setIsCountingDown(true);
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto bg-black min-h-screen relative pb-16">
        <header className="p-4">
          <h1 className="text-xl font-medium text-white">{getViewLabel()}</h1>
        </header>

        <main className="relative h-[calc(100vh-8rem)]">
          <div className="absolute inset-0 bg-black flex items-center justify-center">
            {isCountingDown ? (
              <div className="relative">
                <span className="absolute inset-0 flex items-center justify-center text-[200px] font-bold text-white animate-countdown">
                  {countdown}
                </span>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-48 h-48 rounded-full border-8 border-white animate-pulse" />
                </div>
              </div>
            ) : isAnalyzing ? (
              <div className="text-white text-center">
                <p className="text-lg">Analyzing...</p>
                <div className="w-48 h-1 bg-gray-700 rounded-full mt-4">
                  <div className="w-24 h-1 bg-blue-500 rounded-full animate-pulse" />
                </div>
              </div>
            ) : (
              <div className="text-white text-center">
                <p className="text-lg mb-2">Position yourself to capture your</p>
                <p className="text-2xl font-medium">
                  {view.charAt(0).toUpperCase() + view.slice(1)} View
                </p>
              </div>
            )}
          </div>
        </main>

        <div className="fixed bottom-16 left-0 right-0 p-4">
          <div className="flex justify-around items-center mb-4">
            <button className="p-4 rounded-full text-white/50 hover:text-white/70">
              <RotateCcw className="w-6 h-6" />
            </button>
            <button
              onClick={handleStartRecording}
              disabled={isRecording || isAnalyzing || isCountingDown}
              className={`w-16 h-16 rounded-full flex items-center justify-center transition-all 
                ${isRecording || isAnalyzing || isCountingDown 
                  ? 'bg-gray-600 cursor-not-allowed' 
                  : 'bg-blue-500 hover:bg-blue-600'}`}
            >
              <CameraIcon className="w-8 h-8 text-white" />
            </button>
            <div className="w-14" /> {/* Spacer for alignment */}
          </div>

          <div className="flex flex-col items-center gap-2">
            <p className="text-sm text-white/70 mb-2">
              {isRecording ? 'Recording...' : 'Tap to capture'}
            </p>
            <div className={`w-2 h-2 rounded-full ${view === 'front' ? 'bg-blue-500' : 'bg-gray-300'}`} />
            <div className={`w-2 h-2 rounded-full ${view === 'side' ? 'bg-blue-500' : 'bg-gray-300'}`} />
            <div className={`w-2 h-2 rounded-full ${view === 'back' ? 'bg-blue-500' : 'bg-gray-300'}`} />
          </div>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default Camera;