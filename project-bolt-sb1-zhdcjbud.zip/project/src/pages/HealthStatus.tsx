import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { ArrowLeft, Activity, TrendingUp, AlertCircle, Heart, Timer, BarChart3, ArrowUpRight } from 'lucide-react';
import Navigation from '../components/Navigation';
import RecoveryChart from '../components/RecoveryChart';

const HealthStatus: React.FC = () => {
  const navigate = useNavigate();
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  const metrics = [
    { label: 'Recovery Score', value: '85%', trend: '+5%', color: 'text-[#21E102]' },
    { label: 'Readiness', value: '92%', trend: '+2%', color: 'text-blue-500' },
    { label: 'Strain', value: '7.2', trend: '-0.5', color: 'text-yellow-500' },
    { label: 'Sleep', value: '7.5h', trend: '+0.5h', color: 'text-purple-500' },
  ];

  const injuries = [
    {
      area: 'Right Knee',
      status: 'Recovering',
      progress: 75,
      painLevel: 'Low',
      nextCheckup: '3 days',
    },
    {
      area: 'Left Ankle',
      status: 'Monitoring',
      progress: 90,
      painLevel: 'Minimal',
      nextCheckup: '1 week',
    }
  ];

  const recoveryData = [
    { day: 'Mon', value: 85, details: { sleep: 7.5, strain: 7.2, hydration: 85 } },
    { day: 'Tue', value: 82, details: { sleep: 6.8, strain: 8.1, hydration: 80 } },
    { day: 'Wed', value: 88, details: { sleep: 8.2, strain: 6.5, hydration: 90 } },
    { day: 'Thu', value: 85, details: { sleep: 7.8, strain: 7.0, hydration: 88 } },
    { day: 'Fri', value: 90, details: { sleep: 8.5, strain: 6.2, hydration: 92 } },
    { day: 'Sat', value: 87, details: { sleep: 7.9, strain: 6.8, hydration: 89 } },
    { day: 'Sun', value: 85, details: { sleep: 7.6, strain: 7.1, hydration: 86 } },
  ];

  const handleBarClick = (data: { day: string; value: number; details: any }) => {
    setSelectedDay(data.day);
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-xl font-bold">Health Status</h1>
            <p className="text-sm text-gray-400">Daily health metrics & recovery tracking</p>
          </div>
        </header>

        <main className="p-4 space-y-6">
          {/* Today's Metrics */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Today's Metrics</h2>
            <div className="grid grid-cols-2 gap-4">
              {metrics.map((metric) => (
                <div key={metric.label} className="bg-gray-900 rounded-xl p-4">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-sm text-gray-400">{metric.label}</span>
                    <span className={`text-xs ${metric.color}`}>{metric.trend}</span>
                  </div>
                  <div className="text-2xl font-bold">{metric.value}</div>
                </div>
              ))}
            </div>
          </section>

          {/* Weekly Progress */}
          <section>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Recovery Progress</h2>
              <button 
                onClick={() => navigate('/analysis')}
                className="text-sm text-[#42ACF9]"
              >
                View Details
              </button>
            </div>
            <div className="space-y-4">
              <RecoveryChart data={recoveryData} onBarClick={handleBarClick} />
              
              {selectedDay && (
                <div className="bg-gray-900 rounded-xl p-4 animate-fade-in">
                  <h3 className="text-sm font-medium mb-3">{selectedDay} Details</h3>
                  <div className="grid grid-cols-3 gap-4">
                    {Object.entries(
                      recoveryData.find(d => d.day === selectedDay)?.details || {}
                    ).map(([key, value]) => (
                      <div key={key} className="text-center">
                        <div className="text-sm text-gray-400 mb-1">
                          {key.charAt(0).toUpperCase() + key.slice(1)}
                        </div>
                        <div className="text-lg font-medium">
                          {typeof value === 'number' ? 
                            (key === 'sleep' ? `${value}h` : `${value}%`) : 
                            value}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </section>

          {/* Active Injuries */}
          <section>
            <h2 className="text-lg font-semibold mb-4">Active Injuries</h2>
            <div className="space-y-4">
              {injuries.map((injury) => (
                <div key={injury.area} className="bg-gray-900 rounded-xl p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-medium">{injury.area}</h3>
                      <span className="text-sm text-gray-400">{injury.status}</span>
                    </div>
                    <span className={`text-sm px-2 py-1 rounded-full ${
                      injury.painLevel === 'Low' ? 'bg-[#21E102]/20 text-[#21E102]' :
                      injury.painLevel === 'Minimal' ? 'bg-blue-500/20 text-blue-400' :
                      'bg-yellow-500/20 text-yellow-400'
                    }`}>
                      {injury.painLevel}
                    </span>
                  </div>
                  <div className="space-y-2">
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full bg-gradient-to-r from-[#21E102] to-[#42ACF9]"
                        style={{ width: `${injury.progress}%` }}
                      />
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Recovery Progress</span>
                      <span>{injury.progress}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Next Checkup</span>
                      <span>{injury.nextCheckup}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Quick Actions */}
          <section>
            <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => navigate('/body')}
                className="flex items-center justify-between p-4 bg-[#42ACF9] rounded-xl"
              >
                <div>
                  <span className="text-sm">Update</span>
                  <h3 className="font-medium">Body Status</h3>
                </div>
                <ArrowUpRight className="w-5 h-5" />
              </button>
              <button 
                onClick={() => navigate('/analysis')}
                className="flex items-center justify-between p-4 bg-gray-800 rounded-xl"
              >
                <div>
                  <span className="text-sm">View</span>
                  <h3 className="font-medium">Analysis</h3>
                </div>
                <ArrowUpRight className="w-5 h-5" />
              </button>
            </div>
          </section>
        </main>

        <Navigation />
      </div>
    </div>
  );
};

export default HealthStatus;