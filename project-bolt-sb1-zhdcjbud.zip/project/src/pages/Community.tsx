import React from 'react';
import Navigation from '../components/Navigation';

const Community: React.FC = () => {
  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto bg-black min-h-screen relative pb-16 text-white">
        <header className="p-4">
          <h1 className="text-2xl font-bold">Community</h1>
          <p className="text-sm text-gray-400 mt-1">Connect with fellow athletes</p>
        </header>
        <Navigation />
      </div>
    </div>
  );
};

export default Community;