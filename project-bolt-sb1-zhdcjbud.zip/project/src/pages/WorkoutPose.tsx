import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, RotateCw } from 'lucide-react';
import Navigation from '../components/Navigation';

const WorkoutPose: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    // Simulate analysis delay
    setTimeout(() => {
      navigate(`/workout/${id}/comparison`);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3 border-b border-gray-800">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-xl font-bold">Programs</h1>
            <p className="text-sm text-gray-400">Week 1 • Day {id}</p>
          </div>
        </header>

        {/* Main Content */}
        <div className="p-4">
          <div className="aspect-[3/4] bg-gray-900 rounded-lg overflow-hidden relative">
            <img
              src="https://images.unsplash.com/photo-1594381898411-846e7d193883?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
              alt="Exercise pose"
              className="w-full h-full object-cover"
            />
            {/* Skeleton overlay */}
            <div className="absolute inset-0 flex items-center justify-center">
              <svg width="200" height="400" viewBox="0 0 200 400" className="stroke-white/80">
                <line x1="100" y1="50" x2="100" y2="150" strokeWidth="2" />
                <line x1="100" y1="150" x2="50" y2="250" strokeWidth="2" />
                <line x1="100" y1="150" x2="150" y2="250" strokeWidth="2" />
                <line x1="100" y1="100" x2="50" y2="150" strokeWidth="2" />
                <line x1="100" y1="100" x2="150" y2="150" strokeWidth="2" />
                <circle cx="100" cy="50" r="20" fill="none" strokeWidth="2" />
              </svg>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            <p className="text-sm text-gray-300">
              Stand in front of your camera and match the pose shown above.
              Make sure you're fully visible and in a well-lit area.
            </p>

            {isAnalyzing ? (
              <div className="text-center py-4">
                <RotateCw className="w-8 h-8 animate-spin mx-auto mb-2" />
                <p className="text-sm text-gray-300">Analyzing your pose...</p>
              </div>
            ) : (
              <button
                onClick={handleAnalyze}
                className="w-full py-3 bg-[#42ACF9] text-white font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors"
              >
                Analyze Pose
              </button>
            )}

            <button
              onClick={() => navigate('/dashboard')}
              className="w-full py-3 bg-white/10 text-white font-medium rounded-lg hover:bg-white/20 transition-colors"
            >
              Return to Programs
            </button>
          </div>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default WorkoutPose;