import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Home, User, Dumbbell, Users, Award, Star } from 'lucide-react';
import Navigation from '../components/Navigation';
import InviteModal from '../components/InviteModal';

const WORKOUT_COMPLETION_KEY = 'lastCompletedWorkout';
const TOTAL_POINTS_KEY = 'totalPoints';

const WorkoutDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showReward, setShowReward] = useState<{ day: string; score: string } | null>(null);
  const [completedWorkouts, setCompletedWorkouts] = useState<string[]>([]);
  const [totalPoints, setTotalPoints] = useState<number>(0);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [showWeekSummary, setShowWeekSummary] = useState(false);
  const [showWelcome, setShowWelcome] = useState(() => {
    return !localStorage.getItem('welcomeShown');
  });
  
  // Check for completed workout on mount
  useEffect(() => {
    const lastWorkout = localStorage.getItem(WORKOUT_COMPLETION_KEY);

    if (lastWorkout && !showWeekSummary) {
      const completionData = JSON.parse(lastWorkout);
      
      // Update total points if available
      if (completionData.totalPoints) {
        const newTotal = completionData.totalPoints;
        setTotalPoints(newTotal);
        localStorage.setItem(TOTAL_POINTS_KEY, newTotal.toString());
        setShowWeekSummary(true);
      }
      
      if (!completedWorkouts.includes(completionData.day)) {
        setCompletedWorkouts([completionData.day]);
        // Show reward immediately along with stats update
        setTimeout(() => {
          setShowReward({ day: completionData.day, score: '5/5' });
        }, 500);
        
        // Clear reward after display duration
        setTimeout(() => {
          setShowReward(null);
        }, 2000);
        
        // Clear completion data after processing
        localStorage.removeItem(WORKOUT_COMPLETION_KEY);
      }
    }
  }, [showWeekSummary, completedWorkouts]);

  const weekSummary = [
    { day: 'Sun', score: '0/5' },
    { day: 'Mon', score: '0/5' },
    { day: 'Tue', score: '0/5' },
    { day: 'Wed', score: '0/5' },
    { day: 'Thu', score: '0/5' },
    { day: 'Fri', score: '0/5' },
    { day: 'Sat', score: '0/5' }
  ];

  const handleCompleteWorkout = (day: string) => {
    if (!completedWorkouts.includes(day)) {
      setSelectedDay(day);
      const score = `${Math.floor(Math.random() * 3) + 3}/5`;
      setCompletedWorkouts(prev => [...prev, day]);
      setShowReward({ day, score });
      
      // Highlight the completed workout
      const dayElement = document.querySelector(`[data-day="${day}"]`);
      if (dayElement) {
        dayElement.classList.add('scale-110', 'transition-transform');
      }
      
      setTimeout(() => {
        setShowReward(null);
        setSelectedDay(null);
        if (dayElement) {
          dayElement.classList.remove('scale-110');
        }
      }, 2000);
    }
  };

  // Calculate progress based on completed days
  const completedDays = showWeekSummary ? completedWorkouts.length : 0;
  const progressPercentage = completedDays ? (completedDays / 25) * 100 : 0;

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Welcome Overlay */}
        {showWelcome && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 animate-fade-in">
            <div className="w-[90%] max-w-sm overflow-hidden rounded-2xl bg-gray-900">
              <div className="relative h-48">
                <img
                  src="https://images.unsplash.com/photo-1544919982-b61976f0ba43?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
                  alt="Basketball court"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black">
                  <div className="absolute bottom-0 p-6 w-full">
                    <h1 className="text-3xl font-bold text-white mb-4">
                      Recover Correctly so You Can Play Longer
                    </h1>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <button
                  onClick={() => {
                    setShowWelcome(false);
                    localStorage.setItem('welcomeShown', 'true');
                  }}
                  className="w-full py-3 bg-[#42ACF9] text-white font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors"
                >
                  Get Started
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Header */}
        <header className="p-4">
          <h1 className="text-2xl font-bold">Dashboard</h1>
        </header>

        <main className="px-4 space-y-6">
          {/* Welcome Message */}
          <section className="bg-[#42ACF9]/10 rounded-xl p-4 border border-[#42ACF9]/20">
            <h2 className="text-lg font-semibold mb-2">Welcome to Aisra! 👋</h2>
            <p className="text-sm text-gray-300">
              Let's start your fitness journey together. Complete your first workout to begin tracking your progress.
            </p>
          </section>

          {/* Week Summary */}
          <section>
            <h2 className="text-xl mb-4">Week Summary</h2>
            {showWeekSummary ? (
              <div className="grid grid-cols-7 gap-2 animate-fade-in">
                {weekSummary.map((day, index) => (
                  <div 
                    key={day.day} 
                    className="text-center relative space-y-2"
                  >
                    <div className="text-sm mb-2">{day.day}</div>
                    <div className="flex flex-col items-center gap-1">
                      {completedWorkouts.includes(day.day) ? (
                        <>
                          <div className="relative w-8 h-8" data-day={day.day}>
                            <Award 
                              className={`w-full h-full text-[#21E102] cursor-pointer transition-transform hover:scale-110 ${
                                showReward?.day === day.day ? 'animate-bounce animate-fade-in' : ''
                              }`} 
                              strokeWidth={1.5} 
                            />
                            {showReward?.day === day.day && (
                              <div className="absolute -top-16 left-1/2 -translate-x-1/2 bg-[#21E102] text-white px-3 py-1 rounded-lg text-sm whitespace-nowrap animate-fade-in">
                                Score: {showReward.score}
                                <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-[#21E102] rotate-45" />
                              </div>
                            )}
                          </div>
                          <div className="text-xs font-medium text-white">
                            {showReward?.day === day.day ? showReward.score : '5/5'}
                          </div>
                        </>
                      ) : (
                        <button
                          onClick={() => handleCompleteWorkout(day.day)}
                          className={`w-8 h-8 rounded-full border-2 transition-all duration-300 ${
                            selectedDay === day.day 
                              ? 'border-[#42ACF9] bg-[#42ACF9]' 
                              : 'border-gray-700 hover:border-gray-600'
                          }`}
                        />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-400">
                No Data Yet
              </div>
            )}
          </section>

          {/* Progress */}
          <section>
            <h2 className="text-xl mb-4">Progress</h2>
            <div className="w-full bg-gray-800 rounded-full h-2 mb-2">
              <div 
                className="h-full rounded-full bg-gradient-to-r from-[#21E102] to-[#FF3B30] transition-all duration-1000" 
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <div className="text-right text-sm text-gray-400">{completedDays}/25</div>
          </section>

          {/* Stats */}
          <section className="grid grid-cols-2 gap-4">
            <div className="bg-gray-900 rounded-lg p-4">
              <div className="text-3xl font-bold mb-2">{completedDays}</div>
              <div className="text-sm text-gray-400">Current Streak</div>
            </div>
            <div className="bg-gray-900 rounded-lg p-4">
              <div className="text-3xl font-bold mb-2">{totalPoints}</div>
              <div className="text-sm text-gray-400">Total Points</div>
            </div>
          </section>

          {/* Next Workout */}
          <section>
            <h2 className="text-xl mb-4">Next Workout</h2>
            <div 
              className="bg-gray-900 rounded-lg overflow-hidden cursor-pointer"
              onClick={() => {
                localStorage.setItem('highlightExercises', 'true');
                navigate('/exercises');
              }}
            >
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1434608519344-49d77a699e1d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
                  alt="Next workout"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent">
                  <div className="p-4">
                    <h3 className="text-lg font-bold">First Workout</h3>
                    <p className="text-sm text-gray-300">Get started with your journey</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Progress Message */}
          <section className="text-center px-4">
            <p className="text-gray-400 mb-4">
              Start your fitness journey and track your progress. Invite friends to join you!
            </p>
            <button 
              onClick={() => setShowInviteModal(true)}
              className="w-full py-3 bg-[#42ACF9] rounded-lg text-white font-medium"
            >
              Invite Friends
            </button>
          </section>
        </main>

        <Navigation />
        <InviteModal 
          isOpen={showInviteModal}
          onClose={() => setShowInviteModal(false)}
        />
      </div>
    </div>
  );
};


export default WorkoutDashboard