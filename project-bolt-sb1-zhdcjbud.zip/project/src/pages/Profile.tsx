import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, User2, CreditCard, Settings2, Activity, ClipboardList, Cog, HelpCircle } from 'lucide-react';
import Navigation from '../components/Navigation';

const Profile: React.FC = () => {
  const navigate = useNavigate();

  const menuItems = [
    { icon: User2, label: 'Personal Details', path: '/profile/details' },
    { icon: CreditCard, label: 'Subscription', path: '/profile/subscription' },
    { icon: Settings2, label: 'Preference', path: '/profile/preferences' },
   { icon: Activity, label: 'Health Status', path: '/health-status' },
    { icon: ClipboardList, label: 'Plans', path: '/profile/plans' },
    { icon: Cog, label: 'App settings', path: '/profile/settings' },
    { icon: HelpCircle, label: 'Help & Feedback', path: '/profile/help' },
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        <header className="p-4">
          <h1 className="text-2xl font-bold">Profile</h1>
        </header>

        {/* Status Pills */}
        <div className="flex gap-2 px-4 mb-4">
          <div className="px-4 py-2 bg-purple-500/20 rounded-full">
            <span className="text-purple-300">3 Workout Days</span>
          </div>
          <div className="px-4 py-2 bg-pink-500/20 rounded-full">
            <span className="text-pink-300">4 Rest Days</span>
          </div>
        </div>

        {/* My Profile Button */}
        <div className="px-4 mb-4">
          <button 
            className="w-full p-4 bg-gray-800 rounded-xl flex items-center justify-between"
            onClick={() => navigate('/profile/details')}
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gray-700 rounded-full overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1603415526960-f7e0328c63b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <h2 className="font-medium">My Profile</h2>
                <p className="text-sm text-gray-400">View and edit your profile</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Menu Items */}
        <div className="px-4">
          <div className="bg-gray-800 rounded-xl overflow-hidden">
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <button
                  key={index}
                  className="w-full p-4 flex items-center justify-between hover:bg-gray-700/50 transition-colors"
                  onClick={() => navigate(item.path)}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-5 h-5 text-gray-400" />
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </button>
              );
            })}
          </div>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default Profile;