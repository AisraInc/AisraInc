import React from 'react';
import { useNavigate } from 'react-router-dom';
import Navigation from '../components/Navigation';
import { bodyParts } from '../data/bodyParts';
import { PainPoint } from '../types';

const InjurySummary: React.FC = () => {
  const navigate = useNavigate();
  const savedPainPoints = localStorage.getItem('painPoints');
  const painPoints: PainPoint[] = savedPainPoints ? JSON.parse(savedPainPoints) : [];

  const bodyImageUrl = "https://s3-alpha-sig.figma.com/img/a9d7/be24/f7168e92fd64eb719e28602847587e37?Expires=1738540800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=AvPqp~gW7vty5OJZIdT0txXQI7vrTFHwgjAelODhpI8IdEG~r53E6CZHaFC57gSgF8h0gfkeuvi~tGVSGTFEFahsg-iHMjgIt4HQRWsY7k1L3mB0H24hSBOramQNF88GXUKYLdAAH-HRuZKo3HTmM7yMOYmw8~dgX92Ww47s-f7BoDhFZXEPLKZHV-TqHkg-EW5tGZ97GPC3w1O1dn8j~0aXJQiAEBfPvS6utUJppei3v6zLOCMB2WjVUhn0GJB4xb58Fj3m5ZsYC00TF7a7MV0jpB5GTnx94vealmgtU6pkpBye3-1w9HgwgFhWD4eDVxHTuZmMLh3C6qQ~Dj8fSg__";

  const getPartLabel = (partId: string) => {
    const part = bodyParts.find(p => p.id === partId);
    return part ? part.label : partId;
  };

  const handleEdit = (partId: string) => {
    // Navigate to BodySelection with edit state
    navigate('/', { 
      state: { 
        editPartId: partId 
      } 
    });
  };

  const handleDelete = (partId: string) => {
    // Get current points from localStorage
    const savedPoints = localStorage.getItem('painPoints');
    const currentPoints = savedPoints ? JSON.parse(savedPoints) : [];
    
    // Filter out the deleted point
    const updatedPoints = currentPoints.filter((point: PainPoint) => point.partId !== partId);
    
    // Update localStorage
    localStorage.setItem('painPoints', JSON.stringify(updatedPoints));
    
    // Navigate based on remaining points
    if (updatedPoints.length === 0) {
      navigate('/');
    } else {
      // Refresh the current points without a full page reload
      window.location.reload(); // We keep this for now to ensure UI consistency
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <div className="max-w-md mx-auto bg-black min-h-screen relative pb-16 text-white">
        <header className="p-4">
          <h1 className="text-2xl font-bold text-white">Injury Analysis</h1>
          <p className="text-sm text-gray-400 mt-1">
            Here are the body areas you selected to focus on
          </p>
        </header>

        <main className="divide-y divide-gray-800">
          {painPoints.map((point, index) => (
            <div key={point.partId} className="p-4">
              <h3 className="text-xl font-semibold">{getPartLabel(point.partId)}</h3>
              <div className="space-y-0.5 text-gray-300 mt-1">
                <p>Pain Type - {point.details.type}</p>
                <p>Pain Level - {point.details.level}</p>
                <p>Pain Area - {point.details.area}</p>
                <p>Rotation Pain - {point.details.rotation}</p>
              </div>
              <div className="relative h-48 flex justify-center mt-4">
                <img
                  src={bodyImageUrl}
                  alt="Body model"
                  className="h-full object-contain"
                />
                {/* Add red dot indicator for pain point */}
                <div 
                  className="absolute w-4 h-4 bg-red-500 rounded-full"
                  style={{
                    left: `${point.coordinates.x}%`,
                    top: `${point.coordinates.y}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                />
              </div>
              <div className="flex gap-4 mt-2">
                <button 
                  onClick={() => handleEdit(point.partId)}
                  className="text-gray-400 hover:text-gray-300"
                >
                  Edit
                </button>
                <button 
                  onClick={() => handleDelete(point.partId)}
                  className="text-gray-400 hover:text-gray-300"
                >
                  Delete
                </button>
              </div>
            </div>
          ))}
        </main>

        <div className="fixed bottom-16 left-1/2 transform -translate-x-1/2 w-full max-w-md px-4 space-y-2">
          <button
            onClick={() => navigate('/camera-calibration')}
            className="w-full py-3 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition-colors"
          >
            Confirm
          </button>
          <button
            onClick={() => navigate('/')}
            className="w-full py-3 bg-white/10 text-white font-medium rounded-lg hover:bg-white/20 transition-colors"
          >
            Start Over
          </button>
        </div>

        <Navigation />
      </div>
    </div>
  );
};

export default InjurySummary;