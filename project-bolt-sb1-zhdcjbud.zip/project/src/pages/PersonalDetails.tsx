import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Pencil, ChevronRight } from 'lucide-react';

const PersonalDetails: React.FC = () => {
  const navigate = useNavigate();

  const details = [
    { label: 'Name', value: 'John Graham' },
    { label: 'Gender', value: 'Male' },
    { label: 'Age Group', value: '35-44' },
    { label: 'Weight', value: '78 kg' },
    { label: 'Height', value: '175 cm' },
    { label: 'Fitness Level', value: 'Beginner' },
  ];

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        {/* Header */}
        <header className="p-4 flex items-center gap-3">
          <button 
            onClick={() => navigate('/profile')}
            className="p-2 hover:bg-gray-800 rounded-full transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-bold">Personal Details</h1>
        </header>

        {/* Profile Picture */}
        <div className="px-4 py-6">
          <div className="relative w-24 h-24 mx-auto">
            <img
              src="https://images.unsplash.com/photo-1603415526960-f7e0328c63b1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80"
              alt="Profile"
              className="w-full h-full rounded-full object-cover"
            />
            <button className="absolute bottom-0 right-0 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
              <Pencil className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Details List */}
        <div className="px-4">
          <div className="bg-gray-800 rounded-xl overflow-hidden">
            {details.map((item, index) => (
              <button
                key={index}
                className="w-full p-4 flex items-center justify-between hover:bg-gray-700/50 transition-colors border-b border-gray-700 last:border-0"
              >
                <span className="text-gray-400">{item.label}</span>
                <div className="flex items-center gap-2">
                  <span>{item.value}</span>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PersonalDetails;