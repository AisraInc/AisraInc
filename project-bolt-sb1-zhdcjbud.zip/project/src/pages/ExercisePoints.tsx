import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navigation from '../components/Navigation';
const WORKOUT_COMPLETION_KEY = 'lastCompletedWorkout';
const TOTAL_POINTS_KEY = 'totalPoints';

const ExercisePoints: React.FC = () => {
  const navigate = useNavigate();

  const exerciseSets = [
    {
      setNumber: 1,
      exercises: [
        { name: 'Shoulder Touch (Rt)', points: 10 },
        { name: 'Shoulder Touch (Lt)', points: 10 },
        { name: 'Arm Circles', points: 15 },
        { name: 'Arm Circles (Front)', points: 10 },
        { name: 'Lateral Raises', points: 10 }
      ]
    },
    {
      setNumber: 2,
      exercises: [
        { name: 'Shoulder Touch (Rt)', points: 10 },
        { name: 'Shoulder Touch (Lt)', points: 10 },
        { name: 'Arm Circles', points: 10 },
        { name: 'Arm Circles (Front)', points: 15 },
        { name: 'Lateral Raises', points: 10 }
      ]
    },
    {
      setNumber: 3,
      exercises: [
        { name: 'Shoulder Touch (Rt)', points: 15 },
        { name: 'Shoulder Touch (Lt)', points: 10 },
        { name: 'Arm Circles', points: 10 },
        { name: 'Arm Circles (Front)', points: 10 },
        { name: 'Lateral Raises', points: 10 }
      ]
    }
  ];

  const totalPoints = exerciseSets.reduce((total, set) => 
    total + set.exercises.reduce((setTotal, exercise) => setTotal + exercise.points, 0), 0
  );

  return (
    <div className="min-h-screen bg-black">
      <div className="mx-auto bg-black min-h-screen relative pb-16 text-white" style={{ width: '390px' }}>
        <header className="p-4 space-y-1 border-b border-gray-800">
          <div className="flex flex-col">
            <h1 className="font-montserrat text-[24px] leading-[29.26px] font-semibold tracking-[0%]">Exercise Points Summary</h1>
            <div className="mt-4 space-y-2">
              <div className="grid grid-cols-[120px_1fr] gap-x-4">
              <p className="font-montserrat text-[12px] leading-[14.63px] tracking-[0.04em] text-white">Areas of Focus:</p>
              <p className="font-montserrat text-[12px] leading-[14.63px] tracking-[0.04em] text-white">Shoulders</p>
              </div>
              <div className="grid grid-cols-[120px_1fr] gap-x-4">
              <p className="font-montserrat text-[12px] leading-[14.63px] tracking-[0.04em] text-white">Equipment:</p>
              <p className="font-montserrat text-[12px] leading-[14.63px] tracking-[0.04em] text-white">Body Weight</p>
              </div>
              <div className="grid grid-cols-[120px_1fr] gap-x-4">
              <p className="font-montserrat text-[12px] leading-[14.63px] tracking-[0.04em] text-white">Time:</p>
              <p className="font-montserrat text-[12px] leading-[14.63px] tracking-[0.04em] text-white">15 Minutes</p>
              </div>
            </div>
          </div>
        </header>

        <main className="p-4 pb-24">
          {exerciseSets.map((set, index) => (
            <div key={index} className="mb-6 relative">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[16px] leading-[19.5px] text-[#42ACF9] font-jakarta">Set {set.setNumber}</span>
              </div>
              <div className="bg-black overflow-hidden">
                <div className="grid grid-cols-12 text-base mb-4">
                  <div className="col-span-1">
                    <div className="w-10 h-10 flex items-center justify-center text-white font-jakarta">#</div>
                  </div>
                  <div className="col-span-9 text-center text-white font-jakarta">Exercise</div>
                  <div className="col-span-2 text-right text-white pr-1 font-jakarta">Points</div>
                </div>
                {set.exercises.map((exercise, exIndex) => (
                  <div 
                    key={exIndex}
                    className="grid grid-cols-12 mb-2 last:mb-0 items-center"
                  >
                    <div className="col-span-1">
                      <div className="w-10 h-10 bg-[#979090] flex items-center justify-center text-base font-jakarta">
                        {exIndex + 1}
                      </div>
                    </div>
                    <div className="col-span-9 text-[#42ACF9] text-base text-center font-jakarta">{exercise.name}</div>
                    <div className="col-span-2">
                      <div className="w-10 h-10 bg-[#979090] flex items-center justify-center ml-auto text-base font-jakarta">
                        {exercise.points}
                      </div>
                    </div>
                  </div>
                ))}
                <div className="mt-4 text-base grid grid-cols-12 items-center">
                  <div className="col-span-1">
                    <div className="w-10 h-10 flex items-center justify-center text-white font-jakarta">Total</div>
                  </div>
                  <div className="col-span-9"></div>
                  <div className="col-span-2 text-[#21E102] text-right font-jakarta">
                    {set.exercises.reduce((total, ex) => total + ex.points, 0)}
                  </div>
                </div>
              </div>
            </div>
          ))}

          <div className="bg-white text-black py-4 mb-8">
            <div className="px-4 flex justify-between items-center">
              <span className="text-xl font-medium font-jakarta">Total</span>
              <span className="text-xl font-medium font-jakarta">{totalPoints} Points</span>
            </div>
          </div>
          
          <div className="fixed bottom-16 left-0 right-0 p-4 space-y-2 bg-black" style={{ width: '390px', margin: '0 auto' }}>
            <button
              onClick={() => {
                const completionData = JSON.parse(localStorage.getItem(WORKOUT_COMPLETION_KEY) || '{}');
                completionData.totalPoints = totalPoints;
                localStorage.setItem(TOTAL_POINTS_KEY, totalPoints.toString());
                localStorage.setItem(WORKOUT_COMPLETION_KEY, JSON.stringify(completionData));
                navigate('/dashboard');
              }}
              className="w-full py-3 bg-[#42ACF9] text-black font-medium rounded-2xl"
            >
              Dashboard
            </button>
            <button
              onClick={() => navigate('/exercises')}
              className="w-full py-3 bg-black text-white font-medium border border-white rounded-2xl"
            >
              Back
            </button>
          </div>
        </main>

        <Navigation />
      </div>
    </div>
  );
};

export default ExercisePoints;