import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import BodySelection from './pages/BodySelection';
import Exercises from './pages/Exercises';
import InjurySummary from './pages/InjurySummary';
import CameraCalibration from './pages/CameraCalibration';
import Camera from './pages/Camera';
import WorkoutDashboard from './pages/WorkoutDashboard';
import AddWorkout from './pages/AddWorkout';
import Timer from './pages/Timer';
import AnalysisReport from './pages/AnalysisReport';
import Community from './pages/Community';
import Profile from './pages/Profile';
import PersonalDetails from './pages/PersonalDetails';
import WorkoutDetails from './pages/WorkoutDetails';
import WorkoutPose from './pages/WorkoutPose';
import WorkoutComparison from './pages/WorkoutComparison';
import HealthStatus from './pages/HealthStatus';
import Subscription from './pages/Subscription';
import Preferences from './pages/Preferences';
import AppSettings from './pages/AppSettings';
import Plans from './pages/Plans';
import HelpFeedback from './pages/HelpFeedback';
import ExercisePoints from './pages/ExercisePoints';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<WorkoutDashboard />} />
        <Route path="/dashboard" element={<WorkoutDashboard />} />
        <Route path="/exercises" element={<Exercises />} />
        <Route path="/add-workout" element={<AddWorkout />} />
        <Route path="/timer" element={<Timer />} />
        <Route path="/body" element={<BodySelection />} />
        <Route path="/summary" element={<InjurySummary />} />
        <Route path="/camera-calibration" element={<CameraCalibration />} />
        <Route path="/camera" element={<Camera />} />
        <Route path="/analysis" element={<AnalysisReport />} />
        <Route path="/community" element={<Community />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/profile/details" element={<PersonalDetails />} />
        <Route path="/workout/:id" element={<WorkoutDetails />} />
        <Route path="/workout/:id/pose" element={<WorkoutPose />} />
        <Route path="/workout/:id/comparison" element={<WorkoutComparison />} />
       <Route path="/health-status" element={<HealthStatus />} />
        <Route path="/profile/subscription" element={<Subscription />} />
        <Route path="/profile/preferences" element={<Preferences />} />
        <Route path="/profile/settings" element={<AppSettings />} />
        <Route path="/profile/plans" element={<Plans />} />
        <Route path="/profile/help" element={<HelpFeedback />} />
        <Route path="/exercise-points" element={<ExercisePoints />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;