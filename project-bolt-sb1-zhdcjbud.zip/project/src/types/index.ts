export interface BodyPart {
  id: string;
  label: string;
  width: number;
  height: number;
  x: number;
  y: number;
  rotation: number;
  side?: 'L' | 'R' | 'front' | 'back';
}

export interface PainPoint {
  partId: string;
  coordinates: {
    x: number;
    y: number;
  };
  details: PainDetails;
}

export interface PainDetails {
  level: number;
  type: 'temporary' | 'permanent';
  area: 'front' | 'back' | 'side';
  rotation: 'forward' | 'reverse';