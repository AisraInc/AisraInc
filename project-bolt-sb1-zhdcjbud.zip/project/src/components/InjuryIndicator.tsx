import React from 'react';
import { X } from 'lucide-react';

interface Props {
  label: string;
  onRemove: () => void;
  painLevel: number;
  position: number;
}

const InjuryIndicator: React.FC<Props> = ({ label, onRemove, painLevel, position }) => {
  return (
    <div 
      className="absolute bg-red-400 text-white rounded-md shadow-lg flex items-center gap-2 px-3 py-1.5 z-10 animate-fade-in"
      style={{
        left: position % 2 === 0 ? '1rem' : 'auto',
        right: position % 2 === 1 ? '1rem' : 'auto',
        top: `${4 + position * 3}rem`
      }}
    >
      <span className="text-sm font-medium">{label} (Level {painLevel})</span>
      <button 
        onClick={onRemove}
        className="p-0.5 hover:bg-red-500 rounded-full transition-colors"
      >
        <X className="w-3 h-3" />
      </button>
    </div>
  );
}

export default InjuryIndicator;