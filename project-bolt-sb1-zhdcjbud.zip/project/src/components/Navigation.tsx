import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, User, Dumbbell, Users } from 'lucide-react';

const NAV_WIDTH = '390px'; // Standard iPhone width

const Navigation: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [highlightExercises, setHighlightExercises] = useState(false);

  const isActive = (path: string) => {
    const exercisePaths = ['/exercises', '/timer', '/exercise-points'];
    if (path === '/exercises' && exercisePaths.includes(location.pathname)) return true;
    if (path === '/exercises' && highlightExercises) return true;
    return location.pathname === path;
  };

  // Listen for highlight signal from localStorage
  useEffect(() => {
    const shouldHighlight = localStorage.getItem('highlightExercises') === 'true';
    if (shouldHighlight) {
      setHighlightExercises(true);
      localStorage.removeItem('highlightExercises');
      setTimeout(() => setHighlightExercises(false), 2000);
    }
  }, [location]);

  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 bg-black border-t border-gray-800/50" style={{ width: NAV_WIDTH }}>
      <div className="px-4">
        <div className="flex justify-between py-3">
          <button 
            onClick={() => navigate('/')}
            className={`flex flex-col items-center w-16 ${isActive('/') ? 'text-[#42ACF9]' : 'text-gray-500'}`}
          >
            <Home className="w-6 h-6" />
            <span className="text-[10px] mt-1">Home</span>
          </button>
          <button 
            onClick={() => navigate('/body')}
            className={`flex flex-col items-center w-16 ${isActive('/body') ? 'text-[#42ACF9]' : 'text-gray-500'}`}
          >
            <User className="w-6 h-6" />
            <span className="text-[10px] mt-1">Body</span>
          </button>
          <button 
            onClick={() => navigate('/exercises')}
            className={`flex flex-col items-center w-16 ${isActive('/exercises') ? 'text-[#42ACF9]' : 'text-gray-500'}`}
          >
            <Dumbbell className="w-6 h-6" />
            <span className="text-[10px] mt-1">Exercises</span>
          </button>
          <button 
            onClick={() => navigate('/community')}
            className={`flex flex-col items-center w-16 ${isActive('/community') ? 'text-[#42ACF9]' : 'text-gray-500'}`}
          >
            <Users className="w-6 h-6" />
            <span className="text-[10px] mt-1">Comm.</span>
          </button>
          <button 
            onClick={() => navigate('/profile')}
            className={`flex flex-col items-center w-16 ${isActive('/profile') ? 'text-[#42ACF9]' : 'text-gray-500'}`}
          >
            <User className="w-6 h-6" />
            <span className="text-[10px] mt-1">Profile</span>
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navigation;