import React from 'react';
import { Info } from 'lucide-react';

interface DataPoint {
  day: string;
  value: number;
  details: {
    sleep: number;
    strain: number;
    hydration: number;
  };
}

interface Props {
  data: DataPoint[];
  onBarClick: (data: DataPoint) => void;
}

const RecoveryChart: React.FC<Props> = ({ data, onBarClick }) => {
  return (
    <div className="bg-gray-900 rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-[#21E102]" />
            <span className="text-xs text-gray-400">Recovery</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-[#42ACF9]" />
            <span className="text-xs text-gray-400">Target</span>
          </div>
        </div>
        <button className="p-1 hover:bg-gray-800 rounded-full">
          <Info className="w-4 h-4 text-gray-400" />
        </button>
      </div>
      
      <div className="flex justify-between items-end h-32 mb-2">
        {data.map((point) => (
          <button
            key={point.day}
            onClick={() => onBarClick(point)}
            className="flex flex-col items-center gap-2 group"
          >
            <div className="relative">
              {/* Target line */}
              <div 
                className="absolute w-4 border-t border-[#42ACF9] -translate-x-1"
                style={{ top: `${100 - 85}%` }}
              />
              {/* Recovery bar */}
              <div 
                className="w-2 bg-gradient-to-t from-[#21E102] to-[#42ACF9] rounded-full transition-all group-hover:w-4 group-hover:opacity-80"
                style={{ height: `${point.value}%` }}
              />
            </div>
            <span className="text-xs text-gray-400">{point.day}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default RecoveryChart;