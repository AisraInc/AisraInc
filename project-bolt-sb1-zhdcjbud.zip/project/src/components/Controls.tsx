import React from 'react';
import { Plus, Minus, Focus } from 'lucide-react';

interface Props {
  onZoomIn: () => void;
  onZoomOut: () => void;
  onReset: () => void;
}

const Controls: React.FC<Props> = ({ onZoomIn, onZoomOut, onReset }) => {
  return (
    <div className="absolute right-4 top-1/4 flex flex-col gap-2">
      <button
        onClick={onZoomIn}
        className="p-2 bg-white rounded-full shadow-lg hover:bg-gray-50"
      >
        <Plus className="w-6 h-6" />
      </button>
      <button
        onClick={onZoomOut}
        className="p-2 bg-white rounded-full shadow-lg hover:bg-gray-50"
      >
        <Minus className="w-6 h-6" />
      </button>
      <button
        onClick={onReset}
        className="p-2 bg-white rounded-full shadow-lg hover:bg-gray-50"
      >
        <Focus className="w-6 h-6" />
      </button>
    </div>
  );
}

export default Controls;