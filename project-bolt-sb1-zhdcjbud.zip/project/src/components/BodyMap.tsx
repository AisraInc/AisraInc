import React, { useState } from 'react';
import { Plus, Minus, Focus } from 'lucide-react';
import { bodyParts } from '../data/bodyParts';
import { BodyPart } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface Props {
  selectedParts: string[]; 
  onTogglePart: (partId: string) => void;
  onPartClick: (partId: string, coordinates: { x: number; y: number }) => void;
  view: 'front' | 'back';
  zoom: number;
}

const BodyMap: React.FC<Props> = ({ 
  selectedParts, 
  onTogglePart, 
  onPartClick,
  view, 
  zoom
}) => {
  const [hoveredPart, setHoveredPart] = useState<string | null>(null);
  const [clickedAreas, setClickedAreas] = useState<string[]>([]);
  const [selectedPart, setSelectedPart] = useState<BodyPart | null>(null);

  const frontImageUrl = "https://s3-alpha-sig.figma.com/img/a9d7/be24/f7168e92fd64eb719e28602847587e37?Expires=1740355200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=hfQSYLncYRA8QZvaFLEM410ZpsI9hMSFU5m209eFOT-Hem0n1sA9pDibtlgvlzgxywMJXSWVsyI~jlhdjRgB4kOamCD22p6eRSS9Tw8MmYbluX5g1lTs1J94DjSIKrvBEjMaznDRd2rDG2gGg-SDjdg5ScICHT9C-RyrIW7erriljfMvqrhujwE5p~5XehpJfdbtZof2A-~kyetFxEWMzqm-uY-YHdqz5HbtHIsxDqfltyoWL4~f~kvWkHMIis4xj5WEaUCXg24Ww64oXLXwhijZW4-hdtmXolK9IRYFy17rXT3u0307NExYuSrjQ9Y72NqO9MrxOJB3UgRxj4TTIA__";
  const backImageUrl = "https://s3-alpha-sig.figma.com/img/24c8/e6c0/6989d6b032810af2c2101cb2f14af667?Expires=1740355200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=ZI3Im8AafpF2EzPKzKCTnDG9k6S~phf8ZgLNTIfL~HF5xc9OOiWee10M0lww0UoltuHk6dIVeeSvGCaU9yaTRwmeOoT-hOax-wLZXR3j5ACzwNeE48TPZOYIW94qIrQaZ0qVjzyYMjNwTmsxzXvPRJvEeWpMsYETFDbyAZWIzKlbeh-hCj0d5MmN3UlEEShRfeda3xnW7xvLIXnTLJ4a6ZzNe3vGHODisv29rPcTOLKcf7hOv8yBNha3cswl5~b9sPA6OPpDSZCbpH4XD69vrLv8Ings3m9tcTJ~6NiS9h~CCT1-YoI8qTuMjR2a~n1PwqMr5aFqTWnMMlsnIWdtBA__";

  const visibleParts = bodyParts.filter(part => {
    if (part.side === 'back') return view === 'back';
    if (part.side === 'front') return view === 'front';
    if (part.side === 'L' || part.side === 'R') return view === 'front';
    return true;
  });

  const handlePartClick = (partId: string) => {
    const part = bodyParts.find(p => p.id === partId);
    if (!part) return;
    
    setSelectedPart(part);

    // Toggle clicked state for this area
    setClickedAreas(prev => {
      if (prev.includes(partId)) {
        return prev.filter(id => id !== partId);
      }
      return [...prev, partId];
    });
    
    // Clear previous selection and set new one
    if (selectedParts.includes(partId)) {
      onPartClick(partId, { x: part.x, y: part.y });
    } else {
      onTogglePart(partId);
    }
  };

  const getBoxStyle = (part: BodyPart) => {
    const isClicked = clickedAreas.includes(part.id);
    const isSelected = selectedParts.includes(part.id);
    const isHovered = hoveredPart === part.id;

    let style: React.CSSProperties = {
      position: 'absolute',
      left: `${part.x}px`,
      top: `${part.y}px`,
      width: `${part.width}px`,
      height: `${part.height}px`,
      border: '2px solid #FF0000',
      transform: `rotate(${part.rotation}deg)`,
      transition: 'all 0.2s ease-out',
      cursor: 'pointer',
      zIndex: isHovered ? 30 : isSelected ? 20 : 10,
      backgroundColor: isClicked ? 'rgba(255, 0, 0, 0.2)' : 'transparent',
      borderColor: isClicked ? '#FF0000' : 'transparent',
      borderRadius: '4px',
    };

    if (isHovered) {
      style.backgroundColor = isClicked ? 'rgba(255, 0, 0, 0.3)' : 'transparent';
      style.borderColor = '#FF0000';
    }

    return style;
  };

  const getLabelPosition = (part: BodyPart) => {
    let x = part.x - 100; // Default offset to the left
    const y = part.y - 60;
    
    // Special case for left shoulder - position label on the right side
    if (part.id === 'shoulder-left-front') {
      x = part.x + part.width - 30; // Position to the right of the shoulder, moved a tiny bit more left
    }
    
    return { x, y };
  };

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <img
        src={view === 'front' ? frontImageUrl : backImageUrl}
        alt="Body diagram"
        className="h-full w-auto max-w-full object-contain mx-auto"
        style={{ transform: `scale(${zoom})` }}
      />
      <div className="absolute inset-0">
        {visibleParts.map((part) => (
          <div
            key={part.id}
            style={getBoxStyle(part)}
            onMouseEnter={() => setHoveredPart(part.id)}
            onMouseLeave={() => setHoveredPart(null)}
            onClick={() => handlePartClick(part.id)}
          />
        ))}
      </div>
      
      {/* Part Label */}
      {selectedPart && (
        <div
          className="absolute"
          style={{
            left: getLabelPosition(selectedPart).x,
            top: getLabelPosition(selectedPart).y,
          }}
        >
          <div 
            className="bg-[#FF5F4B] text-black px-4 py-2 rounded-lg shadow-lg text-lg font-medium"
            style={{
              animation: 'fadeIn 0.2s ease-out',
              whiteSpace: 'nowrap'
            }}
          >
            {selectedPart.label}
          </div>
        </div>
      )}
    </div>
  );
};

export default BodyMap;