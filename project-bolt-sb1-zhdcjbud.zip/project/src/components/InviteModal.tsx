import React from 'react';
import { X, Mail, Share2, Copy, MessageCircle } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const InviteModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handleCopyLink = () => {
    const inviteLink = 'https://aisra.fit/invite/xyz123';
    // Try using the modern clipboard API first
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(inviteLink)
        .then(() => {
          alert('Invite link copied to clipboard!');
        })
        .catch(() => {
          // Fallback to legacy approach
          const textArea = document.createElement('textarea');
          textArea.value = inviteLink;
          textArea.style.position = 'fixed';
          textArea.style.left = '-999999px';
          textArea.style.top = '-999999px';
          document.body.appendChild(textArea);
          textArea.focus();
          textArea.select();
          try {
            document.execCommand('copy');
            alert('Invite link copied to clipboard!');
          } catch (err) {
            console.error('Failed to copy text:', err);
          }
          textArea.remove();
        });
    } else {
      // For non-secure contexts, use the legacy approach directly
      const textArea = document.createElement('textarea');
      textArea.value = inviteLink;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        document.execCommand('copy');
        alert('Invite link copied to clipboard!');
      } catch (err) {
        console.error('Failed to copy text:', err);
      }
      textArea.remove();
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        const shareData = {
          title: 'Join me on Aisra',
          text: 'Track your fitness journey and compete with friends!',
          url: 'https://aisra.fit/invite/xyz123',
        };
        
        // Check if we can share all the data
        if (await navigator.canShare?.(shareData)) {
          await navigator.share(shareData);
        } else {
          handleCopyLink();
        }
      } catch (err) {
        // If share fails, fallback to copy link
        handleCopyLink();
      }
    } else {
      handleCopyLink();
    }
  };

  const shareOptions = [
    {
      icon: Mail,
      label: 'Email Invite',
      onClick: () => window.location.href = 'mailto:?subject=Join%20me%20on%20Aisra&body=Track%20your%20fitness%20journey%20and%20compete%20with%20friends!%20https://aisra.fit/invite/xyz123',
    },
    {
      icon: MessageCircle,
      label: 'Send Message',
      onClick: () => window.location.href = 'sms:?&body=Join%20me%20on%20Aisra!%20https://aisra.fit/invite/xyz123',
    },
    {
      icon: Copy,
      label: 'Copy Link',
      onClick: handleCopyLink,
    },
    {
      icon: Share2,
      label: 'Share',
      onClick: handleShare,
    },
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end z-50 animate-fade-in">
      <div className="w-full bg-gray-900 rounded-t-2xl max-w-md mx-auto">
        <div className="p-4 border-b border-gray-800">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-white">Invite Friends</h3>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-gray-800 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>

        <div className="p-4">
          <p className="text-gray-400 mb-6">
            Invite your friends to join you on your fitness journey and compete together!
          </p>

          <div className="grid grid-cols-2 gap-4">
            {shareOptions.map((option) => (
              <button
                key={option.label}
                onClick={option.onClick}
                className="flex flex-col items-center gap-2 p-4 bg-gray-800 rounded-xl hover:bg-gray-700 transition-colors"
              >
                <option.icon className="w-6 h-6 text-[#42ACF9]" />
                <span className="text-sm text-white">{option.label}</span>
              </button>
            ))}
          </div>

          <div className="mt-6 p-4 bg-gray-800 rounded-xl">
            <p className="text-sm text-gray-400 mb-2">Your Invite Link</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 truncate text-white text-sm">
                https://aisra.fit/invite/xyz123
              </div>
              <button
                onClick={handleCopyLink}
                className="px-3 py-1 bg-[#42ACF9] text-white text-sm font-medium rounded-lg hover:bg-[#42ACF9]/90 transition-colors"
              >
                Copy
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InviteModal;