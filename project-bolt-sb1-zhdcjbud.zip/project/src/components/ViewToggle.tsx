import React from 'react';

interface Props {
  view: 'front' | 'back';
  onViewChange: (view: 'front' | 'back') => void;
}

const ViewToggle: React.FC<Props> = ({ view, onViewChange }) => {
  return (
    <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2 bg-white rounded-full shadow-lg p-1">
      <div className="flex items-center">
        <button
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
            ${view === 'front' ? 'bg-blue-500 text-white' : 'text-gray-700'}`}
          onClick={() => onViewChange('front')}
        >
          Front
        </button>
        <button
          className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
            ${view === 'back' ? 'bg-blue-500 text-white' : 'text-gray-700'}`}
          onClick={() => onViewChange('back')}
        >
          Back
        </button>
      </div>
    </div>
  );
}

export default ViewToggle;