import React, { useState } from 'react';
import { X } from 'lucide-react';
import { PainDetails } from '../types';

interface Props {
  partLabel: string;
  onClose: () => void;
  onConfirm: (details: PainDetails) => void;
  initialDetails?: PainDetails;
}

const PainLevelModal: React.FC<Props> = ({ partLabel, onClose, onConfirm, initialDetails }) => {
  const [painLevel, setPainLevel] = useState(initialDetails?.level ?? 1);
  const [painType, setPainType] = useState<'temporary' | 'permanent'>(initialDetails?.type ?? 'temporary');
  const [painArea, setPainArea] = useState<'front' | 'back' | 'side'>(initialDetails?.area ?? 'front');
  const [rotationPain, setRotationPain] = useState<'forward' | 'reverse'>(initialDetails?.rotation ?? 'forward');

  const handleConfirm = () => {
    onConfirm({
      level: painLevel,
      type: painType,
      area: painArea,
      rotation: rotationPain,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-white rounded-2xl w-[90%] max-w-sm overflow-hidden">
        <div className="p-4 border-b border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900">{partLabel}</h3>
        </div>

        <div className="p-4 space-y-4">
          <div>
            <p className="text-sm text-gray-600 mb-2">Pain Level</p>
            <div className="grid grid-cols-5 gap-1">
              {[1, 2, 3, 4, 5].map((level) => (
                <button
                  key={level}
                  onClick={() => setPainLevel(level)}
                  className={`py-2 text-sm font-medium rounded
                    ${painLevel === level
                     ? 'bg-[#FFF500] text-black'
                      : 'bg-gray-100 text-gray-600'}`}
                >
                  {level}
                </button>
              ))}
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-1">
              <span>Low</span>
              <span>High</span>
            </div>
          </div>

          <div>
            <p className="text-sm text-gray-600 mb-2">Pain Type</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setPainType('temporary')}
                className={`py-2 px-4 text-sm font-medium rounded
                  ${painType === 'temporary'
                    ? 'bg-[#FFF500] text-black'
                    : 'bg-gray-100 text-gray-600'}`}
              >
                Temporary
              </button>
              <button
                onClick={() => setPainType('permanent')}
                className={`py-2 px-4 text-sm font-medium rounded
                  ${painType === 'permanent'
                    ? 'bg-[#FFF500] text-black'
                    : 'bg-gray-100 text-gray-600'}`}
              >
                Permanent
              </button>
            </div>
          </div>

          <div>
            <p className="text-sm text-gray-600 mb-2">Pain Area</p>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setPainArea('front')}
                className={`py-2 px-4 text-sm font-medium rounded
                  ${painArea === 'front'
                    ? 'bg-[#FFF500] text-black'
                    : 'bg-gray-100 text-gray-600'}`}
              >
                Front
              </button>
              <button
                onClick={() => setPainArea('back')}
                className={`py-2 px-4 text-sm font-medium rounded
                  ${painArea === 'back'
                    ? 'bg-[#FFF500] text-black'
                    : 'bg-gray-100 text-gray-600'}`}
              >
                Back
              </button>
              <button
                onClick={() => setPainArea('side')}
                className={`py-2 px-4 text-sm font-medium rounded
                  ${painArea === 'side'
                    ? 'bg-[#FFF500] text-black'
                    : 'bg-gray-100 text-gray-600'}`}
              >
                Side
              </button>
            </div>
          </div>

          <div>
            <p className="text-sm text-gray-600 mb-2">Rotation Pain</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setRotationPain('forward')}
                className={`py-2 px-4 text-sm font-medium rounded
                  ${rotationPain === 'forward'
                    ? 'bg-[#FFF500] text-black'
                    : 'bg-gray-100 text-gray-600'}`}
              >
                Forward
              </button>
              <button
                onClick={() => setRotationPain('reverse')}
                className={`py-2 px-4 text-sm font-medium rounded
                  ${rotationPain === 'reverse'
                    ? 'bg-[#FFF500] text-black'
                    : 'bg-gray-100 text-gray-600'}`}
              >
                Reverse
              </button>
            </div>
          </div>
        </div>

        <div className="p-4 space-y-2">
          <button
            onClick={handleConfirm}
            className="w-full py-2.5 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition-colors"
          >
            Confirm
          </button>
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default PainLevelModal;