const YOUTUBE_API_KEY = 'AIzaSyBMGffA4rFC8tqU6BDMh4zUa5zkBA_TbLc';

export const getVideoDetails = async (videoId: string) => {
  try {
    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${videoId}&key=${YOUTUBE_API_KEY}`
    );
    const data = await response.json();
    return data.items[0]?.snippet;
  } catch (error) {
    console.error('Error fetching video details:', error);
    return null;
  }
};